from __future__ import annotations

from io import BytesIO
from math import exp, pi, sin, tau
import random
import struct
import warnings
import wave
from typing import Literal

import pygame

SAMPLE_RATE = 22050
SoundName = Literal["select", "error", "pour", "success"]


def _wav_bytes(duration: float, sample) -> bytes:
    sample_count = round(SAMPLE_RATE * duration)
    samples = bytearray()
    for index in range(sample_count):
        value = max(-1.0, min(1.0, sample(index / SAMPLE_RATE)))
        samples.extend(struct.pack("<h", round(value * 32767)))

    output = BytesIO()
    with wave.open(output, "wb") as wav_file:
        wav_file.setnchannels(1)
        wav_file.setsampwidth(2)
        wav_file.setframerate(SAMPLE_RATE)
        wav_file.writeframes(samples)
    return output.getvalue()


def _selection_sound() -> bytes:
    def sample(time: float) -> float:
        envelope = exp(-time * 23)
        return envelope * (
            0.36 * sin(tau * 880 * time)
            + 0.16 * sin(tau * 1320 * time)
        )

    return _wav_bytes(0.16, sample)


def _error_sound() -> bytes:
    def sample(time: float) -> float:
        envelope = exp(-time * 15)
        frequency = 250 - 75 * min(1.0, time / 0.18)
        return envelope * 0.22 * sin(tau * frequency * time)

    return _wav_bytes(0.2, sample)


def _pour_sound() -> bytes:
    duration = 1.5
    rng = random.Random(37)
    noise = [rng.uniform(-1.0, 1.0) for _ in range(round(SAMPLE_RATE * duration))]
    droplets = sorted(
        (
            rng.uniform(0.08, duration - 0.08),
            rng.uniform(0.018, 0.045),
            rng.uniform(900.0, 2200.0),
        )
        for _ in range(13)
    )
    low_pass = 0.0
    rumble = 0.0
    phase = 0.0
    glug_phase = 0.0

    def sample(time: float) -> float:
        nonlocal glug_phase, low_pass, phase, rumble
        index = min(round(time * SAMPLE_RATE), len(noise) - 1)
        current_noise = noise[index]
        low_pass += (current_noise - low_pass) * 0.045
        rumble += (low_pass - rumble) * 0.012
        bright_noise = current_noise - low_pass
        progress = time / duration
        envelope = min(1.0, time / 0.1) * min(1.0, (duration - time) / 0.2)
        flow = 0.78 + 0.22 * sin(tau * progress * 1.35)
        glug_frequency = 4.7 + 0.55 * sin(tau * progress * 0.8)
        glug_phase += tau * glug_frequency / SAMPLE_RATE
        glug = 0.7 + 0.3 * (0.5 + 0.5 * sin(glug_phase))
        frequency = 5.2 + 0.8 * sin(tau * progress * 1.7)
        phase += tau * frequency / SAMPLE_RATE
        bubbles = max(0.0, sin(phase)) ** 10
        splash = 0.0
        for start, length, frequency in droplets:
            local_time = time - start
            if 0.0 <= local_time < length:
                splash += (
                    (1.0 - local_time / length)
                    * sin(tau * frequency * local_time)
                )
        return envelope * (
            flow * glug * (0.12 * rumble + 0.075 * low_pass + 0.06 * bright_noise)
            + 0.07 * bubbles
            + 0.035 * splash
        )

    return _wav_bytes(duration, sample)


def _success_sound() -> bytes:
    notes = ((659.25, 0.0), (783.99, 0.12), (987.77, 0.24))

    def sample(time: float) -> float:
        value = 0.0
        for frequency, start in notes:
            local_time = time - start
            if local_time >= 0:
                envelope = exp(-local_time * 4.8)
                value += 0.19 * envelope * sin(tau * frequency * local_time)
        return value

    return _wav_bytes(0.9, sample)


class SoundEffects:
    def __init__(self) -> None:
        self._sounds: dict[str, pygame.mixer.Sound] = {}
        try:
            if pygame.mixer.get_init() is None:
                pygame.mixer.init(
                    frequency=SAMPLE_RATE,
                    size=-16,
                    channels=1,
                    buffer=512,
                )
            pygame.mixer.set_num_channels(max(8, pygame.mixer.get_num_channels()))
            self._sounds = {
                "select": pygame.mixer.Sound(buffer=_selection_sound()),
                "error": pygame.mixer.Sound(buffer=_error_sound()),
                "pour": pygame.mixer.Sound(buffer=_pour_sound()),
                "success": pygame.mixer.Sound(buffer=_success_sound()),
            }
            self._sounds["select"].set_volume(0.32)
            self._sounds["error"].set_volume(0.28)
            self._sounds["pour"].set_volume(0.42)
            self._sounds["success"].set_volume(0.38)
        except pygame.error as error:
            warnings.warn(
                f"Spieleaudio konnte nicht initialisiert werden: {error}",
                RuntimeWarning,
                stacklevel=2,
            )
            self._sounds.clear()

    @property
    def available(self) -> bool:
        return bool(self._sounds)

    def play(self, effect: SoundName) -> None:
        sound = self._sounds.get(effect)
        if sound is not None:
            sound.play()
