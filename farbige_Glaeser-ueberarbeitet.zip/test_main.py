import unittest
from unittest.mock import patch

import main


class MainTests(unittest.TestCase):
    def test_main_starts_the_3d_game(self) -> None:
        with patch("panda3d_game.run_3d_game") as run_3d_game:
            main.main()

        run_3d_game.assert_called_once_with()


if __name__ == "__main__":
    unittest.main()
