from __future__ import annotations

from dataclasses import dataclass
from math import acos, cos, degrees, pi, radians, sin, tan, tau
from pathlib import Path
import random
from typing import Any, Literal
import warnings

from direct.gui.DirectGui import DirectButton, DirectFrame, DirectLabel, DGG
from direct.gui.OnscreenText import OnscreenText
from direct.showbase.ShowBase import ShowBase
from panda3d.core import (
    AmbientLight,
    AntialiasAttrib,
    CardMaker,
    ClockObject,
    DirectionalLight,
    Filename,
    Fog,
    Geom,
    GeomNode,
    GeomTriangles,
    GeomVertexData,
    GeomVertexFormat,
    GeomVertexWriter,
    GraphicsWindow,
    LColor,
    LineSegs,
    Material,
    NodePath,
    PointLight,
    Point3,
    Quat,
    TextFont,
    TextNode,
    TransparencyAttrib,
    Vec3,
    WindowProperties,
    loadPrcFileData,
)

from game_progress import (
    DIFFICULTIES,
    Difficulty,
    load_progress,
    progress_file_path,
    save_progress,
)
from sortierlogik import Board, can_pour, create_puzzle, is_solved, pour, top_run_length
from sound_effects import SoundEffects

loadPrcFileData(
    "Farb-Labor 3D",
    "\n".join(
        (
            "window-title Farb-Labor – 3D",
            "fullscreen false",
            "win-size 1600 900",
            "sync-video true",
            "framebuffer-multisample 1",
            "multisamples 4",
            "show-frame-rate-meter false",
            "textures-power-2 none",
            "audio-library-name null",
        )
    ),
)

CAPACITY = 4
ANIMATION_DURATION = 2.35
POUR_START = 0.48
POUR_END = 1.62
TILT_END = 0.42
STREAM_FADE_DURATION = 0.16
STREAM_END = 1.72
RETURN_START = 1.78
TUBE_HEIGHT = 2.86
LIQUID_BASE = 0.22
LIQUID_SLOT_HEIGHT = 0.57
TUBE_SPACING = 1.28

PALETTE = (
    ("Koralle", (255, 48, 91)),
    ("Ozeanblau", (32, 111, 255)),
    ("Sonnengelb", (255, 207, 36)),
    ("Grün", (110, 255, 0)),
    ("Violett", (166, 72, 255)),
    ("Rosa", (255, 57, 179)),
    ("Türkis", (0, 245, 230)),
    ("Mandarine", (255, 105, 24)),
    ("Limette", (194, 255, 0)),
)
DIFFICULTY_LABELS = {
    "leicht": "Leicht",
    "mittel": "Mittel",
    "schwer": "Schwer",
}
UI_BOLD_FONT_PATHS = (
    Path("C:/Windows/Fonts/seguisb.ttf"),
    Path("C:/Windows/Fonts/segoeuib.ttf"),
    Path("C:/Windows/Fonts/Candarab.ttf"),
    Path("C:/Windows/Fonts/calibrib.ttf"),
    Path("C:/Windows/Fonts/trebucbd.ttf"),
    Path("C:/Windows/Fonts/corbelb.ttf"),
    Path("C:/Windows/Fonts/arialbd.ttf"),
    Path("C:/Windows/Fonts/tahomabd.ttf"),
    Path("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"),
    Path("/usr/share/fonts/truetype/liberation2/LiberationSans-Bold.ttf"),
    Path("/usr/share/fonts/truetype/freefont/FreeSansBold.ttf"),
)
UI_REGULAR_FONT_PATHS = (
    Path("C:/Windows/Fonts/segoeui.ttf"),
    Path("C:/Windows/Fonts/Candara.ttf"),
    Path("C:/Windows/Fonts/calibri.ttf"),
    Path("C:/Windows/Fonts/trebuc.ttf"),
    Path("C:/Windows/Fonts/corbel.ttf"),
    Path("C:/Windows/Fonts/arial.ttf"),
    Path("C:/Windows/Fonts/tahoma.ttf"),
    Path("/System/Library/Fonts/Supplemental/Arial.ttf"),
    Path("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"),
    Path("/usr/share/fonts/truetype/liberation2/LiberationSans-Regular.ttf"),
)
UI_FONT_PATHS = UI_BOLD_FONT_PATHS + UI_REGULAR_FONT_PATHS
UI_FONT_RENDER_MODE = TextFont.RM_texture
UI_FONT_PIXELS_PER_UNIT = 128
UI_PRIMARY_TEXT_COLOR = (0.98, 0.97, 0.95, 1.0)
UI_SECONDARY_TEXT_COLOR = (0.92, 0.92, 0.90, 1.0)
UI_HINT_BUTTON_TEXT_COLOR = (0.12, 0.09, 0.04, 1.0)


@dataclass(frozen=True)
class DifficultySettings:
    starting_colors: int
    levels_per_color: int
    empty_tubes: int
    scramble_base: int
    scramble_per_color: int
    capacity: int = CAPACITY
    max_scramble_pour: int | None = None
    max_colors: int = 7


DIFFICULTY_SETTINGS: dict[Difficulty, DifficultySettings] = {
    "leicht": DifficultySettings(2, 3, 3, 30, 8),
    "mittel": DifficultySettings(3, 2, 2, 55, 14),
    "schwer": DifficultySettings(9, 1, 1, 600, 80, 6, 3, 9),
}


@dataclass
class PourAnimation:
    source: int
    target: int
    color: int
    amount: int
    elapsed: float = 0


@dataclass
class CelebrationParticle:
    node: NodePath
    velocity_x: float
    velocity_z: float
    spin: float
    color: tuple[float, float, float]
    elapsed: float = 0.0
    duration: float = 2.8


def _material(
    name: str,
    diffuse: tuple[float, float, float, float],
    ambient: tuple[float, float, float, float],
    specular: tuple[float, float, float, float],
    shininess: float,
) -> Material:
    material = Material(name)
    material.setDiffuse(LColor(*diffuse))
    material.setAmbient(LColor(*ambient))
    material.setSpecular(LColor(*specular))
    material.setShininess(shininess)
    return material


def _lathe_model(
    name: str,
    profile: tuple[tuple[float, float], ...],
    color: tuple[float, float, float, float],
    *,
    segments: int = 48,
    gradient: bool = False,
) -> NodePath:
    vertex_data = GeomVertexData(name, GeomVertexFormat.getV3n3c4(), Geom.UHStatic)
    vertex_data.setNumRows(len(profile) * (segments + 1))
    vertices = GeomVertexWriter(vertex_data, "vertex")
    normals = GeomVertexWriter(vertex_data, "normal")
    colors = GeomVertexWriter(vertex_data, "color")

    z_min = min(z for _, z in profile)
    z_max = max(z for _, z in profile)
    for row, (radius, height) in enumerate(profile):
        previous_radius, previous_height = profile[row - 1]
        next_radius, next_height = profile[(row + 1) % len(profile)]
        normal_x = next_height - previous_height
        normal_z = previous_radius - next_radius
        normal_length = max(0.001, (normal_x * normal_x + normal_z * normal_z) ** 0.5)
        for segment in range(segments + 1):
            angle = tau * segment / segments
            c, s = cos(angle), sin(angle)
            vertices.addData3(radius * c, radius * s, height)
            if radius <= 0.001:
                normals.addData3(0, 0, -1 if height <= z_min + 0.001 else 1)
            else:
                normals.addData3(
                    normal_x * c / normal_length,
                    normal_x * s / normal_length,
                    normal_z / normal_length,
                )
            light = 1.0
            if gradient:
                light = 0.72 + 0.34 * max(
                    0.0,
                    min(1.0, (height - z_min) / max(0.001, z_max - z_min)),
                )
            colors.addData4(
                min(1.0, color[0] * light),
                min(1.0, color[1] * light),
                min(1.0, color[2] * light),
                color[3],
            )

    triangles = GeomTriangles(Geom.UHStatic)
    ring_width = segments + 1
    for row in range(len(profile)):
        next_row = (row + 1) % len(profile)
        for segment in range(segments):
            first = row * ring_width + segment
            next_first = next_row * ring_width + segment
            triangles.addVertices(first, first + 1, next_first)
            triangles.addVertices(first + 1, next_first + 1, next_first)
    triangles.closePrimitive()

    geometry = Geom(vertex_data)
    geometry.addPrimitive(triangles)
    node = GeomNode(name)
    node.addGeom(geometry)
    model = NodePath(node)
    model.setTwoSided(True)
    return model


GLASS_PROFILE = (
    (0.00, 0.13),
    (0.22, 0.13),
    (0.31, 0.15),
    (0.37, 0.22),
    (0.39, 0.32),
    (0.39, 2.60),
    (0.41, 2.70),
    (0.47, 2.73),
    (0.49, 2.78),
    (0.47, 2.84),
    (0.40, 2.87),
    (0.35, 2.84),
    (0.34, 2.77),
    (0.34, 0.34),
    (0.30, 0.26),
    (0.00, 0.26),
)

GLASS_TRIM_PROFILE = (
    (0.390, 0.000),
    (0.390, 0.014),
    (0.405, 0.022),
    (0.424, 0.018),
    (0.424, 0.006),
    (0.408, 0.000),
)

LIQUID_PROFILE = (
    (0.00, 0.00),
    (0.26, 0.00),
    (0.31, 0.035),
    (0.325, 0.09),
    (0.325, 0.49),
    (0.31, 0.54),
    (0.27, 0.57),
    (0.00, 0.57),
)


class Panda3DColorSortGame(ShowBase):
    def __init__(self) -> None:
        super().__init__()
        self._configure_fullscreen_window()
        self.disableMouse()
        self.setBackgroundColor(0.007, 0.009, 0.013, 1)
        self.render.setShaderAuto()
        self.ui_font = self._load_ui_font()

        self.progress_path = progress_file_path()
        self.level, self.difficulty = load_progress(self.progress_path)
        self.capacity = DIFFICULTY_SETTINGS[self.difficulty].capacity
        self.liquid_slot_height = LIQUID_SLOT_HEIGHT * CAPACITY / self.capacity
        self.board: Board = []
        self.starting_board: Board = []
        self.history: list[Board] = []
        self.move_count = 0
        self.selected_tube: int | None = None
        self.hinted_move: tuple[int, int] | None = None
        self.animation: PourAnimation | None = None
        self.status_message = ""
        self.reduced_motion = False
        self.show_color_names = False
        self.inspected_tube: int | None = None
        self.fullscreen_mode = True
        self.sound_effects = SoundEffects()
        self.tube_roots: list[NodePath] = []
        self.vessel_roots: list[NodePath] = []
        self.liquid_roots: list[NodePath] = []
        self.liquid_surfaces: list[NodePath] = []
        self.liquid_parts: list[list[NodePath]] = []
        self.liquid_part_colors: list[list[int]] = []
        self.vessel_highlights: list[NodePath] = []
        self.pedestals: list[NodePath] = []
        self.pedestal_feet: list[NodePath] = []
        self.contact_shadows: list[NodePath] = []
        self.vessel_trims: list[NodePath] = []
        self.pedestal_display_states: list[str | None] = []
        self.status_leds: list[NodePath] = []
        self.status_led_states: list[str | None] = []
        self.tube_buttons: list[DirectButton] = []
        self.tube_numbers: list[OnscreenText] = []
        self.tube_state_labels: list[OnscreenText] = []
        self.stream_segments: list[NodePath] = []
        self.stream_ripple: NodePath | None = None
        self.tube_accents: list[NodePath] = []
        self.ui_time = 0.0
        self.celebration_elapsed: float | None = None
        self.celebration_particles: list[CelebrationParticle] = []
        self.asset_root = self.render.attachNewNode("shared-render-models")
        self._make_materials()
        self._make_scene()
        self._make_ui()
        self._bind_input()
        self._start_level()
        self.taskMgr.add(self._update, "update-color-sort-game")

    def _configure_fullscreen_window(self) -> None:
        if (
            self.win is None
            or not isinstance(self.win, GraphicsWindow)
            or self.pipe is None
        ):
            return
        width = self.pipe.getDisplayWidth()
        height = self.pipe.getDisplayHeight()
        if width <= 0 or height <= 0:
            return
        properties = WindowProperties()
        properties.setSize(width, height)
        properties.setOrigin(0, 0)
        properties.setFullscreen(True)
        self.win.requestProperties(properties)

    def _make_materials(self) -> None:
        self.glass_material = _material(
            "clear borosilicate glass",
            (0.46, 0.67, 0.82, 0.18),
            (0.13, 0.20, 0.28, 0.16),
            (0.96, 0.99, 1.0, 1),
            128,
        )
        self.glass_trim_material = _material(
            "satin platinum glass trim",
            (0.48, 0.68, 0.76, 1),
            (0.19, 0.28, 0.33, 1),
            (0.92, 0.97, 1, 1),
            96,
        )
        self.foot_material = _material(
            "satin titanium pedestal foot",
            (0.20, 0.31, 0.40, 1),
            (0.09, 0.14, 0.19, 1),
            (0.68, 0.78, 0.88, 1),
            72,
        )
        self.base_material = _material(
            "machined dark alloy",
            (0.13, 0.20, 0.29, 1),
            (0.06, 0.09, 0.14, 1),
            (0.50, 0.62, 0.76, 1),
            58,
        )
        self.status_led_material = _material(
            "status light diffuser",
            (1, 1, 1, 1),
            (0.7, 0.7, 0.7, 1),
            (0.25, 0.25, 0.25, 1),
            32,
        )
        self.status_led_material.setEmission(LColor(0.8, 0.8, 0.8, 1))
        self.completed_base_material = _material(
            "completed tube green pedestal",
            (0.20, 0.86, 0.34, 1),
            (0.14, 0.52, 0.22, 1),
            (0.42, 0.85, 0.52, 1),
            58,
        )
        self.completed_base_material.setEmission(LColor(0.12, 0.48, 0.18, 1))
        self.target_base_material = _material(
            "available target pedestal",
            (0.03, 0.72, 0.78, 1),
            (0.02, 0.35, 0.42, 1),
            (0.18, 0.92, 1.0, 1),
            72,
        )
        self.target_base_material.setEmission(LColor(0.02, 0.58, 0.72, 1))
        self.shadow_material = _material(
            "soft contact shadow",
            (0.008, 0.012, 0.020, 0.34),
            (0.004, 0.006, 0.010, 0.34),
            (0, 0, 0, 1),
            1,
        )
        self.glass_highlight_material = _material(
            "glass reflection highlight",
            (0.92, 0.98, 1.0, 0.28),
            (0.46, 0.58, 0.70, 0.24),
            (1.0, 1.0, 1.0, 1),
            128,
        )
        self.floor_material = _material(
            "matte laboratory surface",
            (0.045, 0.063, 0.092, 1),
            (0.035, 0.048, 0.072, 1),
            (0.09, 0.13, 0.19, 1),
            18,
        )
        self.liquid_surface_material = _material(
            "glossy liquid surface",
            (0.68, 0.80, 0.96, 0.62),
            (0.18, 0.24, 0.32, 0.64),
            (0.95, 0.98, 1.0, 1),
            96,
        )
        self.liquid_models: list[NodePath] = []
        for name, rgb in PALETTE:
            color = tuple(channel / 255 for channel in rgb)
            material = _material(
                f"{name} liquid",
                (*color, 1),
                (color[0] * 0.62, color[1] * 0.62, color[2] * 0.62, 1),
                (0.72, 0.82, 0.96, 1),
                84,
            )
            material.setEmission(
                LColor(color[0] * 0.26, color[1] * 0.26, color[2] * 0.26, 1)
            )
            model = _lathe_model(
                f"{name} volumetric liquid",
                LIQUID_PROFILE,
                (1, 1, 1, 1),
                segments=40,
                gradient=True,
            )
            model.setMaterial(material, 1)
            model.reparentTo(self.asset_root)
            self.liquid_models.append(model)

    def _make_scene(self) -> None:
        self.camLens.setFov(44)
        self.camLens.setAspectRatio(self.getAspectRatio())
        self.camera.setPos(0, -12.8, 6.3)
        self.camera.lookAt(0, 0, 1.2)
        self.render.setAntialias(AntialiasAttrib.MAuto)
        self.scene_fog = Fog("soft laboratory depth")
        self.scene_fog.setColor(0.007, 0.010, 0.016)
        self.scene_fog.setExpDensity(0.008)
        self.render.setFog(self.scene_fog)

        ambient = AmbientLight("cool ambient fill")
        ambient.setColor((0.24, 0.28, 0.36, 1))
        self.render.setLight(self.render.attachNewNode(ambient))

        key_light = DirectionalLight("large soft key light")
        key_light.setColor((0.82, 0.77, 0.68, 1))
        key_path = self.render.attachNewNode(key_light)
        key_path.setHpr(-28, -48, 0)
        self.render.setLight(key_path)

        rim_light = DirectionalLight("cool rim light")
        rim_light.setColor((0.22, 0.44, 0.68, 1))
        rim_path = self.render.attachNewNode(rim_light)
        rim_path.setHpr(148, -16, 0)
        self.render.setLight(rim_path)

        floor_mesh = self._make_ground_plane()
        floor_mesh.reparentTo(self.render)
        self._make_ground_grid()

        self.stage_light = PointLight("liquid highlight")
        self.stage_light.setColor((0.34, 0.48, 0.70, 1))
        light_path = self.render.attachNewNode(self.stage_light)
        light_path.setPos(0, -3.2, 6.8)
        self.render.setLight(light_path)

        self.surface_model = _lathe_model(
            "glossy liquid meniscus",
            (
                (0.00, 0.000),
                (0.22, 0.000),
                (0.29, 0.004),
                (0.32, 0.014),
                (0.30, 0.022),
                (0.20, 0.024),
                (0.00, 0.024),
            ),
            (1, 1, 1, 1),
            segments=48,
            gradient=True,
        )
        self.surface_model.setMaterial(self.liquid_surface_material, 1)
        self.surface_model.setTransparency(TransparencyAttrib.MAlpha)
        self.surface_model.setDepthWrite(False)
        self.surface_model.setBin("transparent", -2)
        self.surface_model.reparentTo(self.asset_root)

        self.contact_shadow_model = _lathe_model(
            "soft circular contact shadow",
            (
                (0.00, 0.000),
                (0.48, 0.000),
                (0.48, 0.004),
                (0.00, 0.004),
            ),
            (1, 1, 1, 1),
            segments=48,
        )
        self.contact_shadow_model.setMaterial(self.shadow_material, 1)
        self.contact_shadow_model.setTransparency(TransparencyAttrib.MAlpha)
        self.contact_shadow_model.setDepthWrite(False)
        self.contact_shadow_model.setBin("transparent", -1)
        self.contact_shadow_model.setLightOff(1)
        self.contact_shadow_model.reparentTo(self.asset_root)

        self.vessel_model = _lathe_model(
            "thick walled rounded test tube",
            GLASS_PROFILE,
            (1, 1, 1, 1),
            segments=64,
        )
        self.vessel_model.setMaterial(self.glass_material, 1)
        self.vessel_model.setTransparency(TransparencyAttrib.MAlpha)
        self.vessel_model.setDepthWrite(False)
        self.vessel_model.setBin("transparent", 0)
        self.vessel_model.reparentTo(self.asset_root)
        self.glass_highlight_model = self._make_box(
            "vertical glass reflection highlight",
            (0.035, 0.014, 2.08),
            self.glass_highlight_material,
        )
        self.glass_highlight_model.setTransparency(TransparencyAttrib.MAlpha)
        self.glass_highlight_model.setDepthWrite(False)
        self.glass_highlight_model.setBin("transparent", 2)
        self.glass_highlight_model.reparentTo(self.asset_root)
        self.vessel_trim_model = _lathe_model(
            "precision satin glass collars",
            GLASS_TRIM_PROFILE,
            (1, 1, 1, 1),
            segments=64,
        )
        self.vessel_trim_model.setMaterial(self.glass_trim_material, 1)
        self.vessel_trim_model.reparentTo(self.asset_root)
        self.stream_model = _lathe_model(
            "liquid stream segment",
            ((0.035, 0), (0.035, 0.5), (0.035, 1)),
            (1, 1, 1, 1),
            segments=16,
        )
        self.stream_model.reparentTo(self.asset_root)
        self.ripple_model = _lathe_model(
            "liquid impact ripple",
            (
                (0.10, 0),
                (0.11, 0.012),
                (0.17, 0.012),
                (0.18, 0),
                (0.17, -0.012),
                (0.11, -0.012),
            ),
            (1, 1, 1, 1),
            segments=32,
        )
        self.ripple_model.reparentTo(self.asset_root)
        self.tube_accent_model = _lathe_model(
            "glass selection ring",
            (
                (0.42, 0.00),
                (0.44, 0.025),
                (0.52, 0.025),
                (0.55, 0.00),
            ),
            (1, 1, 1, 1),
            segments=48,
        )
        self.tube_accent_model.reparentTo(self.asset_root)
        self.asset_root.hide()

    def _load_ui_font(self):
        for font_path in UI_FONT_PATHS:
            if font_path.is_file():
                font = self.loader.loadFont(
                    str(Filename.fromOsSpecific(str(font_path)))
                )
                if font is not None:
                    font.setNativeAntialias(True)
                    font.setRenderMode(UI_FONT_RENDER_MODE)
                    font.setPixelsPerUnit(UI_FONT_PIXELS_PER_UNIT)
                    font.setTextureMargin(3)
                    self.ui_font_path = font_path
                    return font
        self.ui_font_path = None
        warnings.warn(
            "Keine passende Systemschrift gefunden; Panda3D verwendet die Standardschrift.",
            RuntimeWarning,
            stacklevel=2,
        )
        return None

    def _make_box(
        self,
        name: str,
        size: tuple[float, float, float],
        material: Material,
    ) -> NodePath:
        width, depth, height = size
        vertex_data = GeomVertexData(name, GeomVertexFormat.getV3n3c4(), Geom.UHStatic)
        vertex_data.setNumRows(56)
        vertex_writer = GeomVertexWriter(vertex_data, "vertex")
        normal_writer = GeomVertexWriter(vertex_data, "normal")
        color_writer = GeomVertexWriter(vertex_data, "color")
        triangles = GeomTriangles(Geom.UHStatic)
        bevel = min(0.04, width * 0.12, depth * 0.12, height * 0.3)
        rings = (
            (-height / 2, bevel),
            (-height / 2 + bevel, 0),
            (height / 2 - bevel, 0),
            (height / 2, bevel),
        )
        corners = ((-1, -1), (1, -1), (1, 1), (-1, 1))
        points = [
            [
                (sx * (width / 2 - inset), sy * (depth / 2 - inset), z)
                for sx, sy in corners
            ]
            for z, inset in rings
        ]
        row = 0

        def add_face(
            face_points: tuple[tuple[float, float, float], ...],
            normal: tuple[float, float, float],
        ) -> None:
            nonlocal row
            for point in face_points:
                vertex_writer.addData3(*point)
                normal_writer.addData3(*normal)
                color_writer.addData4(1, 1, 1, 1)
            triangles.addVertices(row, row + 1, row + 2)
            triangles.addVertices(row, row + 2, row + 3)
            row += 4

        add_face(tuple(reversed(points[0])), (0, 0, -1))
        add_face(tuple(points[-1]), (0, 0, 1))
        for lower, upper in zip(points, points[1:]):
            for side in range(4):
                next_side = (side + 1) % 4
                p0, p1 = lower[side], lower[next_side]
                p2, p3 = upper[next_side], upper[side]
                edge = tuple(p1[i] - p0[i] for i in range(3))
                rise = tuple(p3[i] - p0[i] for i in range(3))
                normal = (
                    edge[1] * rise[2] - edge[2] * rise[1],
                    edge[2] * rise[0] - edge[0] * rise[2],
                    edge[0] * rise[1] - edge[1] * rise[0],
                )
                magnitude = max(0.001, sum(value * value for value in normal) ** 0.5)
                normal = tuple(value / magnitude for value in normal)
                add_face((p0, p1, p2, p3), normal)
        triangles.closePrimitive()
        geometry = Geom(vertex_data)
        geometry.addPrimitive(triangles)
        node = GeomNode(name)
        node.addGeom(geometry)
        result = NodePath(node)
        result.setMaterial(material, 1)
        result.setTwoSided(True)
        return result

    def _make_ground_grid(self) -> None:
        grid = LineSegs("subtle laboratory floor grid")
        grid.setThickness(1)
        grid.setColor(0.10, 0.19, 0.25, 0.24)
        for x in range(-12, 13):
            grid.moveTo(x, -6, -0.275)
            grid.drawTo(x, 8, -0.275)
        for y in range(-6, 9):
            grid.moveTo(-12, y, -0.275)
            grid.drawTo(12, y, -0.275)
        grid_node = self.render.attachNewNode(grid.create())
        grid_node.setLightOff(1)
        grid_node.setTransparency(TransparencyAttrib.MAlpha)
        grid_node.setDepthWrite(False)
        grid_node.setBin("transparent", -3)

    def _make_ground_plane(self) -> NodePath:
        vertex_data = GeomVertexData(
            "laboratory ground",
            GeomVertexFormat.getV3n3c4(),
            Geom.UHStatic,
        )
        vertex_data.setNumRows(4)
        vertices = GeomVertexWriter(vertex_data, "vertex")
        normals = GeomVertexWriter(vertex_data, "normal")
        colors = GeomVertexWriter(vertex_data, "color")
        for x, y in (
            (-10000, -10000),
            (10000, -10000),
            (10000, 10000),
            (-10000, 10000),
        ):
            vertices.addData3(x, y, -0.28)
            normals.addData3(0, 0, 1)
            colors.addData4(1, 1, 1, 1)
        triangles = GeomTriangles(Geom.UHStatic)
        triangles.addVertices(0, 1, 2)
        triangles.addVertices(0, 2, 3)
        triangles.closePrimitive()
        geometry = Geom(vertex_data)
        geometry.addPrimitive(triangles)
        node = GeomNode("ground plane")
        node.addGeom(geometry)
        result = NodePath(node)
        result.setMaterial(self.floor_material, 1)
        return result

    def _make_ui(self) -> None:
        aspect = self.getAspectRatio()
        self.header_panel = DirectFrame(
            frameColor=(0.020, 0.026, 0.036, 0.96),
            frameSize=(-0.82, 0.82, -0.105, 0.105),
            relief=DGG.FLAT,
            pos=(0, 0, 0.80),
            state=DGG.DISABLED,
        )
        self.header_panel.setBin("fixed", -12)
        self.header_dividers = []
        for x in (-0.23, 0.23):
            divider = DirectFrame(
                frameColor=(0.20, 0.34, 0.42, 0.45),
                frameSize=(-0.0015, 0.0015, -0.070, 0.070),
                relief=DGG.FLAT,
                pos=(x, 0, 0.80),
                state=DGG.DISABLED,
            )
            divider.setBin("fixed", -11)
            self.header_dividers.append(divider)
        self.stat_panel_base_x = (-0.69, 0.0, 0.69)
        self.stat_panels = []
        self.stat_panel_accents = []
        stat_accent_colors = (
            (0.10, 0.84, 0.95, 0.95),
            (0.98, 0.70, 0.30, 0.95),
            (0.30, 0.90, 0.68, 0.95),
        )
        for x, accent_color in zip(self.stat_panel_base_x, stat_accent_colors):
            panel = DirectFrame(
                frameColor=(0.038, 0.045, 0.055, 0.98),
                frameSize=(-0.145, 0.145, -0.044, 0.044),
                relief=DGG.FLAT,
                pos=(x, 0, 0.80),
                state=DGG.DISABLED,
            )
            panel.setBin("fixed", -10)
            self.stat_panels.append(panel)
            accent = DirectFrame(
                frameColor=accent_color,
                frameSize=(-0.034, 0.034, -0.002, 0.002),
                relief=DGG.FLAT,
                pos=(x, 0, 0.844),
                state=DGG.DISABLED,
            )
            accent.setBin("fixed", -9)
            self.stat_panel_accents.append(accent)
        self.action_panel = DirectFrame(
            frameColor=(0.027, 0.032, 0.040, 0.98),
            frameSize=(-0.83, 0.83, -0.078, 0.078),
            relief=DGG.FLAT,
            pos=(0, 0, -0.83),
            state=DGG.DISABLED,
        )
        self.action_panel_accent = DirectFrame(
            frameColor=(0.10, 0.84, 0.88, 0.78),
            frameSize=(-0.22, 0.22, -0.0015, 0.0015),
            relief=DGG.FLAT,
            pos=(0, 0, -0.752),
            state=DGG.DISABLED,
        )
        self.action_panel_accent.setBin("fixed", -9)
        self.title_accent = DirectFrame(
            frameColor=(1.0, 0.72, 0.16, 1),
            frameSize=(-0.055, 0.055, -0.002, 0.002),
            relief=DGG.FLAT,
            pos=(0, 0, 0.855),
            state=DGG.DISABLED,
        )
        self.title_accent.setBin("fixed", -9)
        self.title_text = OnscreenText(
            text="FARB-LABOR",
            pos=(0, 0.94),
            scale=0.060,
            font=self.ui_font,
            fg=UI_PRIMARY_TEXT_COLOR,
            align=TextNode.ACenter,
            shadow=(0, 0, 0, 0.55),
            shadowOffset=(0.014, 0.014),
            mayChange=True,
        )
        self.title_text.setBin("fixed", 10)
        self.subtitle_text = OnscreenText(
            text="FLÜSSIGKEITEN SORTIEREN",
            pos=(0, 0.89),
            scale=0.029,
            font=self.ui_font,
            fg=UI_SECONDARY_TEXT_COLOR,
            align=TextNode.ACenter,
            shadow=(0, 0, 0, 0.5),
            shadowOffset=(0.012, 0.012),
            mayChange=True,
        )
        self.subtitle_text.setBin("fixed", 10)
        self.level_text = self._hud_text((-0.69, 0.80), "LEVEL 01", scale=0.036)
        self.level_buttons = [
            self._make_button("<", (-0.84, 0.80), self._previous_level),
            self._make_button(">", (-0.54, 0.80), self._next_level),
        ]
        for button in self.level_buttons:
            button["text_scale"] = 0.025
            button["frameSize"] = (-0.045, 0.045, -0.035, 0.035)
        self.level_button_base_x = (-0.84, -0.54)
        self.difficulty_text = OnscreenText(
            text="SCHWIERIGKEIT",
            pos=(0, 0.73),
            scale=0.025,
            font=self.ui_font,
            fg=UI_PRIMARY_TEXT_COLOR,
            align=TextNode.ACenter,
            shadow=(0, 0, 0, 0.55),
            shadowOffset=(0.012, 0.012),
            mayChange=True,
        )
        self.difficulty_text.setBin("fixed", 10)
        self.difficulty_button_base_x = (-0.31, 0.0, 0.31)
        self.difficulty_buttons = [
            self._make_button(
                difficulty.upper(),
                (position, 0.68),
                lambda selected=difficulty: self._select_difficulty(selected),
            )
            for difficulty, position in zip(
                DIFFICULTIES,
                self.difficulty_button_base_x,
            )
        ]
        for button in self.difficulty_buttons:
            button["text_scale"] = 0.026
            button["frameSize"] = (-0.14, 0.14, -0.027, 0.027)
        self.difficulty_button_default_colors = [
            button["frameColor"] for button in self.difficulty_buttons
        ]
        self.difficulty_button_selected_colors = (
            (0.08, 0.48, 0.34, 1),
            (0.12, 0.62, 0.42, 1),
            (0.05, 0.35, 0.25, 1),
            (0.08, 0.48, 0.34, 1),
        )
        self.moves_text = self._hud_text((0.0, 0.80), "ZÜGE 00", scale=0.036)
        self.empty_text = self._hud_text((0.69, 0.80), "FREI 02", scale=0.036)
        self.status_text = OnscreenText(
            text="",
            pos=(0, -0.69),
            scale=0.042,
            font=self.ui_font,
            fg=UI_PRIMARY_TEXT_COLOR,
            align=TextNode.ACenter,
            shadow=(0, 0, 0, 0.65),
            shadowOffset=(0.014, 0.014),
            mayChange=True,
        )
        self.status_text.setBin("fixed", 10)
        self.status_panel = DirectFrame(
            frameColor=(0.025, 0.037, 0.050, 0.92),
            frameSize=(-0.58, 0.58, -0.048, 0.048),
            relief=DGG.FLAT,
            pos=(0, 0, -0.69),
            state=DGG.DISABLED,
        )
        self.status_panel.setBin("fixed", -11)
        self.status_accent = DirectFrame(
            frameColor=(0.10, 0.84, 0.88, 0.82),
            frameSize=(-0.12, 0.12, -0.002, 0.002),
            relief=DGG.FLAT,
            pos=(0, 0, -0.742),
            state=DGG.DISABLED,
        )
        self.status_accent.setBin("fixed", -10)
        self.status_text.reparentTo(self.status_panel)
        self.status_accent.reparentTo(self.status_panel)
        self.celebration_text = OnscreenText(
            text="LEVEL GESCHAFFT!\nAlle Farben sind sortiert!",
            pos=(0, 0.18),
            scale=0.075,
            font=self.ui_font,
            fg=(0.58, 0.98, 0.75, 1),
            align=TextNode.ACenter,
            shadow=(0, 0, 0, 0.8),
            shadowOffset=(0.045, 0.045),
            mayChange=True,
        )
        self.celebration_text.setBin("fixed", 20)
        self.celebration_text.hide()
        confetti_card = CardMaker("celebration-confetti-card")
        confetti_card.setFrame(-0.012, 0.012, -0.021, 0.021)
        self.celebration_card_model = self.aspect2d.attachNewNode(
            confetti_card.generate()
        )
        self.celebration_card_model.setTransparency(TransparencyAttrib.MAlpha)
        self.celebration_card_model.setDepthWrite(False)
        self.celebration_card_model.setBin("fixed", 19)
        self.celebration_card_model.hide()

        self.action_buttons = [
            self._make_button(
                "Zurück",
                (-0.60, -0.83),
                self._undo,
                style="utility",
            ),
            self._make_button("Neu starten", (-0.20, -0.83), self._restart),
            self._make_button("Nächstes Level", (0.20, -0.83), self._next_level),
            self._make_button(
                "Tipp",
                (0.60, -0.83),
                self._show_hint,
                style="hint",
            ),
        ]
        self.action_button_default_colors = [
            button["frameColor"] for button in self.action_buttons
        ]
        self.action_icons = []
        for symbol in ("<", "R", ">", "?"):
            icon = DirectLabel(
                text=symbol,
                pos=(0, 0, -0.83),
                text_scale=0.024,
                text_font=self.ui_font,
                text_fg=UI_PRIMARY_TEXT_COLOR,
                text_align=TextNode.ARight,
                frameColor=(0, 0, 0, 0),
                relief=DGG.FLAT,
            )
            icon.setBin("fixed", 12)
            self.action_icons.append(icon)
        self.action_icons[-1]["text_fg"] = UI_HINT_BUTTON_TEXT_COLOR
        self.next_level_button = self.action_buttons[2]
        self.next_level_button_default_colors = self.next_level_button["frameColor"]
        self.next_level_button_is_blinking = False
        self.next_level_button_colors = (
            (0.04, 0.62, 0.27, 1),
            (0.08, 0.78, 0.36, 1),
            (0.02, 0.44, 0.19, 1),
        )
        self.quit_button = self._make_button(
            "Spiel beenden",
            (aspect - 0.18, -0.95),
            self.userExit,
            style="quiet",
        )
        self.quit_button["frameSize"] = (-0.16, 0.16, -0.032, 0.032)
        self.quit_button["text_scale"] = 0.025
        self.motion_button = self._make_button(
            "Effekte: an", (0, -0.95), self._toggle_reduced_motion, style="quiet"
        )
        self.color_names_button = self._make_button(
            "Farbnamen: aus", (0, -0.95), self._toggle_color_names, style="quiet"
        )
        self.window_button = self._make_button(
            "Fenster", (0, -0.95), self._toggle_window_mode, style="quiet"
        )
        self.utility_buttons = [
            self.motion_button,
            self.color_names_button,
            self.window_button,
            self.quit_button,
        ]
        for button in self.utility_buttons:
            button["frameSize"] = (-0.17, 0.17, -0.030, 0.030)
            button["text_scale"] = 0.021
        self.action_button_base_x = (-0.60, -0.20, 0.20, 0.60)
        self.action_icon_base_offsets = (-0.13, -0.13, -0.13, -0.13)

    def _hud_text(
        self,
        position: tuple[float, float],
        text: str,
        *,
        scale: float = 0.027,
        color: tuple[float, float, float, float] = UI_PRIMARY_TEXT_COLOR,
    ) -> OnscreenText:
        text_node = OnscreenText(
            text=text,
            pos=position,
            scale=scale,
            font=self.ui_font,
            fg=color,
            align=TextNode.ACenter,
            shadow=(0, 0, 0, 0.55),
            shadowOffset=(0.012, 0.012),
            mayChange=True,
        )
        text_node.setBin("fixed", 10)
        return text_node

    def _make_button(
        self,
        text: str,
        position: tuple[float, float],
        command,
        *,
        style: Literal[
            "default", "danger", "success", "utility", "hint", "quiet"
        ] = "default",
    ) -> DirectButton:
        colors = {
            "default": (
                (0.09, 0.13, 0.19, 1),
                (0.14, 0.22, 0.32, 1),
                (0.05, 0.08, 0.13, 1),
            ),
            "danger": (
                (0.82, 0.08, 0.19, 1),
                (1.0, 0.12, 0.25, 1),
                (0.64, 0.04, 0.13, 1),
            ),
            "success": (
                (0.04, 0.60, 0.29, 1),
                (0.08, 0.76, 0.37, 1),
                (0.02, 0.42, 0.20, 1),
            ),
            "utility": (
                (0.04, 0.47, 0.41, 1),
                (0.06, 0.64, 0.54, 1),
                (0.02, 0.34, 0.30, 1),
            ),
            "hint": (
                (0.95, 0.54, 0.04, 1),
                (1.0, 0.72, 0.08, 1),
                (0.72, 0.34, 0.01, 1),
            ),
            "quiet": (
                (0.055, 0.070, 0.090, 1),
                (0.095, 0.125, 0.150, 1),
                (0.035, 0.045, 0.060, 1),
            ),
        }
        base, hover, pressed = colors[style]
        return DirectButton(
            text=text,
            text_scale=0.040,
            text_font=self.ui_font,
            text_fg=UI_HINT_BUTTON_TEXT_COLOR if style == "hint"
            else UI_SECONDARY_TEXT_COLOR if style == "quiet"
            else UI_PRIMARY_TEXT_COLOR,
            text_align=TextNode.ACenter,
            frameColor=(base, hover, pressed, base),
            frameSize=(-0.20, 0.20, -0.047, 0.047),
            relief=DGG.FLAT,
            pos=(position[0], 0, position[1]),
            command=command,
            rolloverSound=None,
            clickSound=None,
            pressEffect=True,
        )

    def _bind_input(self) -> None:
        self.accept("escape", self._clear_selection)
        self.accept("h", self._show_hint)
        self.accept("u", self._undo)
        self.accept("r", self._restart)
        self.accept("n", self._next_level)
        self.accept("arrow_left", self._previous_level)
        self.accept("arrow_right", self._next_level)
        self.accept("m", self._toggle_reduced_motion)
        self.accept("c", self._toggle_color_names)
        self.accept("f", self._toggle_window_mode)
        self.accept("mouse3", self._inspect_tube_under_pointer)
        self.accept("q", self.userExit)
        self.accept("window-event", self._on_window_event)

    def _on_window_event(self, window) -> None:
        if window == self.win:
            self._sync_window_mode()
        self._resize_controls(window)

    def _sync_window_mode(self) -> None:
        if isinstance(self.win, GraphicsWindow):
            fullscreen = self.win.getProperties().getFullscreen()
            if fullscreen == self.fullscreen_mode:
                return
            self.fullscreen_mode = fullscreen
            self.window_button["text"] = (
                "Fenster" if self.fullscreen_mode else "Vollbild"
            )

    def _tube_centers(self) -> list[float]:
        count = len(self.board)
        spacing = min(TUBE_SPACING, 10.0 / max(1, count - 1))
        first = -spacing * (count - 1) / 2
        return [first + index * spacing for index in range(count)]

    def _start_level(self) -> None:
        self._stop_celebration()
        settings = DIFFICULTY_SETTINGS[self.difficulty]
        self.capacity = settings.capacity
        self.liquid_slot_height = LIQUID_SLOT_HEIGHT * CAPACITY / self.capacity
        color_count = min(
            settings.starting_colors + (self.level - 1) // settings.levels_per_color,
            settings.max_colors,
        )
        self.board = create_puzzle(
            color_count=color_count,
            empty_tubes=settings.empty_tubes,
            capacity=self.capacity,
            scramble_steps=(
                settings.scramble_base + color_count * settings.scramble_per_color
            ),
            max_scramble_pour=settings.max_scramble_pour,
        )
        self.starting_board = self._copy_board(self.board)
        self.history.clear()
        self.move_count = 0
        self.selected_tube = None
        self.hinted_move = None
        self.inspected_tube = None
        self.animation = None
        self.status_message = "Wähle ein gefülltes Startglas (S)."
        self._rebuild_tubes()
        self._sync_hud()

    @staticmethod
    def _copy_board(board: Board) -> Board:
        return [tube.copy() for tube in board]

    def _rebuild_tubes(self) -> None:
        centers = self._tube_centers()
        if self.tube_roots and len(self.tube_roots) == len(centers):
            for root, center, vessel in zip(
                self.tube_roots,
                centers,
                self.vessel_roots,
            ):
                root.setPos(center, 0, 0.02)
                vessel.setPos(0, 0, 0.13)
                vessel.setQuat(Quat.identQuat())
            for index in range(len(self.tube_roots)):
                self._update_liquid(index)
            self._resize_controls()
            self._update_tube_accents()
            return

        for node in self.tube_roots:
            node.removeNode()
        for button in self.tube_buttons:
            button.destroy()
        for label in self.tube_numbers:
            label.destroy()
        for label in self.tube_state_labels:
            label.destroy()
        self.tube_roots.clear()
        self.vessel_roots.clear()
        self.liquid_roots.clear()
        self.liquid_surfaces.clear()
        self.liquid_parts.clear()
        self.liquid_part_colors.clear()
        self.vessel_highlights.clear()
        self.pedestals.clear()
        self.pedestal_feet.clear()
        self.contact_shadows.clear()
        self.vessel_trims.clear()
        self.pedestal_display_states.clear()
        self.status_leds.clear()
        self.status_led_states.clear()
        self.tube_buttons.clear()
        self.tube_numbers.clear()
        self.tube_state_labels.clear()
        self.tube_accents.clear()

        for index, center in enumerate(centers):
            root = self.render.attachNewNode(f"tube-{index}")
            root.setPos(center, 0, 0.02)
            contact_shadow = self.contact_shadow_model.copyTo(root)
            contact_shadow.show()
            contact_shadow.setPos(0, 0.03, -0.205)
            contact_shadow.setScale(1.05, 0.76, 1)
            self.contact_shadows.append(contact_shadow)
            foot = self._make_box(
                f"tube-{index}-satin-pedestal-foot",
                (1.01, 0.84, 0.045),
                self.foot_material,
            )
            foot.reparentTo(root)
            foot.setPos(0, 0.03, -0.025)
            self.pedestal_feet.append(foot)

            pedestal = self._make_box(
                f"tube-{index}-machined-pedestal",
                (0.95, 0.78, 0.16),
                self.base_material,
            )
            pedestal.reparentTo(root)
            pedestal.setPos(0, 0.03, 0.04)
            self.pedestals.append(pedestal)
            self.pedestal_display_states.append(None)

            status_led = self._make_box(
                f"tube-{index}-status-light",
                (0.42, 0.024, 0.025),
                self.status_led_material,
            )
            status_led.reparentTo(root)
            status_led.setPos(0, -0.365, 0.04)
            status_led.setLightOff(1)
            self.status_leds.append(status_led)
            self.status_led_states.append(None)

            accent = self.tube_accent_model.copyTo(root)
            accent.show()
            accent.setPos(0, 0, 0.14)
            accent.setLightOff(1)
            accent.setTransparency(TransparencyAttrib.MAlpha)
            accent.setColorScale(0.36, 0.62, 0.76, 0.2)
            self.tube_accents.append(accent)

            vessel = root.attachNewNode(f"vessel-{index}")
            vessel.setPos(0, 0, 0.13)
            glass = self.vessel_model.copyTo(vessel)
            glass.show()
            glass.setMaterial(self.glass_material, 1)
            glass.setTransparency(TransparencyAttrib.MAlpha)
            glass.setDepthWrite(False)
            glass.setBin("transparent", 0)
            highlight = self.glass_highlight_model.copyTo(vessel)
            highlight.show()
            highlight.setPos(-0.25, -0.34, 1.45)
            self.vessel_highlights.append(highlight)
            for trim_height in (0.18, 2.79):
                trim = self.vessel_trim_model.copyTo(vessel)
                trim.show()
                trim.setMaterial(self.glass_trim_material, 1)
                trim.setPos(0, 0, trim_height)
                trim_scale = 0.83 if trim_height < 1 else 1.18
                trim.setScale(trim_scale, trim_scale, 1)
                self.vessel_trims.append(trim)
            liquid_root = vessel.attachNewNode(f"liquid-{index}")
            liquid_surface = self.surface_model.copyTo(liquid_root)
            liquid_surface.show()

            self.tube_roots.append(root)
            self.vessel_roots.append(vessel)
            self.liquid_roots.append(liquid_root)
            self.liquid_surfaces.append(liquid_surface)
            self.liquid_parts.append([])
            self.liquid_part_colors.append([])
            self._update_liquid(index)

            button = DirectButton(
                text="",
                frameColor=(0, 0, 0, 0),
                frameSize=(-0.072, 0.072, -0.39, 0.39),
                relief=DGG.FLAT,
                pos=(0, 0, 0),
                command=self._handle_tube_click,
                extraArgs=[index],
                rolloverSound=None,
                clickSound=None,
            )
            self.tube_buttons.append(button)
            number = OnscreenText(
                text=str(index + 1),
                pos=(0, -0.54),
                scale=0.038,
                font=self.ui_font,
                fg=UI_PRIMARY_TEXT_COLOR,
                align=TextNode.ACenter,
                shadow=(0, 0, 0, 0.55),
                shadowOffset=(0.012, 0.012),
                mayChange=True,
            )
            number.setBin("fixed", 10)
            self.tube_numbers.append(number)
            state_label = OnscreenText(
                text="",
                pos=(0, -0.50),
                scale=0.026,
                font=self.ui_font,
                fg=UI_PRIMARY_TEXT_COLOR,
                align=TextNode.ACenter,
                shadow=(0, 0, 0, 0.75),
                shadowOffset=(0.012, 0.012),
                mayChange=True,
            )
            state_label.setBin("fixed", 10)
            self.tube_state_labels.append(state_label)

        self._resize_controls()
        self._update_tube_accents()

    def _update_liquid(self, index: int) -> None:
        liquid_root = self.liquid_roots[index]
        parts = self.liquid_parts[index]
        part_colors = self.liquid_part_colors[index]
        current_height = LIQUID_BASE
        segments = self._liquid_segments(index)
        for segment_index, (color_id, fraction) in enumerate(segments):
            if fraction <= 0.001:
                continue
            if segment_index == len(parts):
                liquid = self.liquid_models[color_id].copyTo(liquid_root)
                liquid.show()
                parts.append(liquid)
                part_colors.append(color_id)
            else:
                liquid = parts[segment_index]
                if part_colors[segment_index] != color_id:
                    liquid.removeNode()
                    liquid = self.liquid_models[color_id].copyTo(liquid_root)
                    liquid.show()
                    parts[segment_index] = liquid
                    part_colors[segment_index] = color_id
                else:
                    liquid.show()
            liquid.setPos(
                0,
                0,
                current_height - (0.003 if segment_index else 0),
            )
            liquid.setScale(
                1,
                1,
                fraction * self.liquid_slot_height / LIQUID_SLOT_HEIGHT,
            )
            current_height += self.liquid_slot_height * fraction
        for liquid in parts[len(segments):]:
            liquid.hide()

        surface = self.liquid_surfaces[index]
        if segments:
            top_color = PALETTE[segments[-1][0]][1]
            surface.setPos(0, 0, current_height - 0.024)
            surface.setColorScale(
                *(0.45 + channel / 255 * 0.55 for channel in top_color),
                0.78,
            )
            surface.show()
        else:
            surface.hide()

    def _liquid_segments(self, index: int) -> list[tuple[int, float]]:
        segments: list[tuple[int, float]] = []
        for color in self.board[index]:
            if segments and segments[-1][0] == color:
                previous, fraction = segments[-1]
                segments[-1] = (previous, fraction + 1)
            else:
                segments.append((color, 1.0))

        animation = self.animation
        if animation is None or index not in (animation.source, animation.target):
            return segments
        progress = min(
            1.0,
            max(
                0.0,
                (animation.elapsed - POUR_START) / (POUR_END - POUR_START),
            ),
        )
        progress = progress * progress * (3 - 2 * progress)
        transferred = animation.amount * progress

        if index == animation.source:
            while transferred > 0.0001 and segments:
                color, fraction = segments[-1]
                drained = min(fraction, transferred)
                fraction -= drained
                transferred -= drained
                if fraction <= 0.0001:
                    segments.pop()
                else:
                    segments[-1] = (color, fraction)
        elif segments and segments[-1][0] == animation.color:
            color, fraction = segments[-1]
            segments[-1] = (color, fraction + transferred)
        else:
            while transferred > 0.0001:
                portion = min(1.0, transferred)
                segments.append((animation.color, portion))
                transferred -= portion
        return segments

    def _liquid_surface_point(self, index: int) -> Point3:
        height = LIQUID_BASE + sum(
            fraction * self.liquid_slot_height
            for _, fraction in self._liquid_segments(index)
        )
        return self.liquid_roots[index].getMat(self.render).xformPoint(
            Point3(0, 0, height)
        )

    def _resize_controls(self, _window=None) -> None:
        del _window
        if not self.board or not self.tube_buttons:
            return
        aspect = self.getAspectRatio()
        self.camLens.setAspectRatio(aspect)
        centers = self._tube_centers()
        board_width = max(6.0, centers[-1] - centers[0] + 1.2)
        narrow_layout = aspect < 0.9
        portrait_factor = max(0.0, min(1.0, (0.9 - aspect) / 0.5))
        fov = 44 + 12 * portrait_factor
        self.camLens.setFov(fov)
        distance = max(
            13.8,
            board_width / (2 * tan(radians(fov / 2))) * 1.25,
        )
        target_z = 1.2 + 0.24 * portrait_factor
        self.camera.setPos(
            0,
            -distance * (0.929 - 0.04 * portrait_factor),
            target_z + distance * (0.37 - 0.02 * portrait_factor),
        )
        self.camera.lookAt(0, 0, target_z)

        layout_scale = min(1.0, aspect / 0.9)
        header_scale = layout_scale
        self.header_panel.setZ(0.80)
        self.header_panel.setScale(header_scale, 1, 1)
        for divider, base_x in zip(self.header_dividers, (-0.23, 0.23)):
            divider.show()
            divider.setX(base_x * header_scale)
            divider.setScale(header_scale, 1, 1)
        self.title_text.setPos(0, 0.94)
        self.subtitle_text.setPos(0, 0.89)
        self.title_accent.setZ(0.855)
        self.title_text.setScale(0.060 * layout_scale)
        self.subtitle_text.setScale(0.029 * layout_scale)
        self.celebration_text.setScale(0.075 * layout_scale)
        self._layout_status(aspect)
        for panel, base_x in zip(self.stat_panels, self.stat_panel_base_x):
            panel.setX(base_x * header_scale)
            panel.setZ(0.80)
            panel.setScale(layout_scale)
        for accent, base_x in zip(self.stat_panel_accents, self.stat_panel_base_x):
            accent.setX(base_x * header_scale)
            accent.setZ(0.844)
            accent.setScale(layout_scale)
        self.level_text.setPos(-0.69 * header_scale, 0.80)
        self.level_text.setScale(0.036 * layout_scale)
        self.moves_text.setPos(0.0, 0.80)
        self.moves_text.setScale(0.036 * layout_scale)
        self.empty_text.setPos(0.69 * header_scale, 0.80)
        self.empty_text.setScale(0.036 * layout_scale)
        for button, base_x in zip(self.level_buttons, self.level_button_base_x):
            button.setX(base_x * header_scale)
            button.setZ(0.80)
            button.setScale(layout_scale)
        self.difficulty_text.setPos(0, 0.73)
        self.difficulty_text.setScale(0.025 * layout_scale)
        for button, base_x in zip(
            self.difficulty_buttons,
            self.difficulty_button_base_x,
        ):
            button.setX(base_x * layout_scale)
            button.setZ(0.68)
            button.setScale(layout_scale)
        if aspect < 0.5:
            compact_scale = min(1.0, aspect / 0.3)
            self.header_panel.setZ(0.79)
            for divider in self.header_dividers:
                divider.hide()
            self.title_text.setPos(0, 0.95)
            self.title_text.setScale(0.046 * compact_scale)
            self.subtitle_text.setPos(0, 0.90)
            self.subtitle_text.setScale(0.020 * compact_scale)
            self.title_accent.setZ(0.885)
            positions = (
                (0.0, 0.83, compact_scale),
                (-0.145 * compact_scale, 0.755, 0.75 * compact_scale),
                (0.145 * compact_scale, 0.755, 0.75 * compact_scale),
            )
            for panel, accent, (x, z, scale) in zip(
                self.stat_panels, self.stat_panel_accents, positions
            ):
                panel.setPos(x, 0, z)
                panel.setScale(scale)
                accent.setPos(x, 0, z + 0.044 * scale)
                accent.setScale(scale)
            for text, (x, z, scale) in zip(
                (self.level_text, self.moves_text, self.empty_text), positions
            ):
                text.setPos(x, z)
                text.setScale(0.031 * scale)
            for button, x in zip(self.level_buttons, (-0.19, 0.19)):
                button.setPos(x * compact_scale, 0, 0.83)
                button.setScale(0.8 * compact_scale)
            self.difficulty_text.setPos(0, 0.69)
            self.difficulty_text.setScale(0.022 * compact_scale)
            for button, x in zip(self.difficulty_buttons, (-0.18, 0.0, 0.18)):
                button.setPos(x * compact_scale, 0, 0.64)
                button.setScale(0.6 * compact_scale)
        if narrow_layout:
            self.action_panel["frameSize"] = (
                -min(0.83, aspect * 0.92),
                min(0.83, aspect * 0.92),
                -0.085,
                0.085,
            )
            self.action_panel.setZ(-0.765)
            self.action_panel.setScale(1, 1, 1)
            self.action_panel_accent.setZ(-0.68)
            self.action_panel_accent.setScale(1, 1, 1)
            button_positions = (
                (-aspect * 0.46, -0.725),
                (aspect * 0.46, -0.725),
                (-aspect * 0.46, -0.805),
                (aspect * 0.46, -0.805),
            )
            action_scale = min(0.8, aspect * 2.2)
        else:
            self.action_panel["frameSize"] = (-0.83, 0.83, -0.078, 0.078)
            self.action_panel.setZ(-0.83)
            self.action_panel_accent.setZ(-0.752)
            self.action_panel.setScale(layout_scale, 1, 1)
            self.action_panel_accent.setScale(layout_scale, 1, 1)
            button_positions = tuple(
                (base_x * layout_scale, -0.83)
                for base_x in self.action_button_base_x
            )
            action_scale = layout_scale
        for button, (base_x, z_position) in zip(
            self.action_buttons,
            button_positions,
        ):
            button.setX(base_x)
            button.setZ(z_position)
            button.setScale(action_scale)
        for icon, button, offset in zip(
            self.action_icons,
            self.action_buttons,
            self.action_icon_base_offsets,
        ):
            icon.setX(button.getX() + offset * action_scale)
            icon.setZ(button.getZ())
            icon.setScale(action_scale)

        if narrow_layout:
            utility_scale = min(1.0, aspect * 2.4)
            utility_positions = (
                (-aspect * 0.46, -0.895),
                (aspect * 0.46, -0.895),
                (-aspect * 0.46, -0.965),
                (aspect * 0.46, -0.965),
            )
        else:
            utility_scale = min(1.0, aspect / 0.75)
            utility_positions = tuple(
                (x * utility_scale, -0.95) for x in (-0.54, -0.18, 0.18, 0.54)
            )
        for button, (x, z) in zip(self.utility_buttons, utility_positions):
            button.setPos(x, 0, z)
            button.setScale(utility_scale)

        projected_tube_x: list[float] = []
        glass_radius = max(radius for radius, _ in GLASS_PROFILE)
        glass_bottom = min(height for _, height in GLASS_PROFILE)
        glass_top = max(height for _, height in GLASS_PROFILE)
        for index, vessel in enumerate(self.vessel_roots):
            points: list[Point3] = []
            for height in (glass_bottom, glass_top):
                for x in (-glass_radius, glass_radius):
                    camera_point = self.cam.getRelativePoint(vessel, Point3(x, 0, height))
                    point = Point3()
                    if self.camLens.project(camera_point, point):
                        points.append(point)
            if len(points) == 4:
                left = min(point.x for point in points) * aspect
                right = max(point.x for point in points) * aspect
                bottom = min(point.y for point in points)
                top = max(point.y for point in points)
                button = self.tube_buttons[index]
                screen_x = (left + right) / 2
                screen_z = (bottom + top) / 2
                button.setPos(screen_x, 0, screen_z)
                button["frameSize"] = (
                    left - screen_x, right - screen_x,
                    bottom - screen_z, top - screen_z,
                )
                projected_tube_x.append(screen_x)
                self.tube_numbers[index].setPos(
                    screen_x,
                    bottom - 0.045,
                )
                self.tube_state_labels[index].setPos(
                    screen_x,
                    bottom + 0.025,
                )
            else:
                projected_tube_x.append(self.tube_buttons[index].getX())
        for index, button in enumerate(self.tube_buttons):
            neighbor_distances = []
            if index > 0:
                neighbor_distances.append(
                    projected_tube_x[index] - projected_tube_x[index - 1]
                )
            if index + 1 < len(projected_tube_x):
                neighbor_distances.append(
                    projected_tube_x[index + 1] - projected_tube_x[index]
                )
            _, projected_half_width, bottom, top = button["frameSize"]
            half_width = (
                min(projected_half_width, min(neighbor_distances) * 0.48)
                if neighbor_distances else projected_half_width
            )
            button["frameSize"] = (-half_width, half_width, bottom, top)
            if neighbor_distances:
                spacing = min(neighbor_distances)
                self.tube_numbers[index].setScale(min(0.038, spacing * 0.65))
                self.tube_state_labels[index].setScale(min(0.026, spacing * 0.7))

    def _layout_status(self, aspect: float) -> None:
        half_width = min(0.58, aspect * 0.92)
        scale = 0.042
        narrow_layout = aspect < 0.9
        self.status_panel.setPos(0, 0, -0.52 if narrow_layout else -0.69)
        self.status_text.setScale(scale)
        self.status_text.setPos(0, 0)
        self.status_text.setZ(0)
        self.status_text.setWordwrap((2 * half_width - 0.04) / scale)
        bounds = self.status_text.getTightBounds(self.status_panel)
        if bounds is None:
            height = 0.04
        else:
            height = bounds[1].z - bounds[0].z
            max_height = 0.20 if narrow_layout else 0.14
            if height > max_height:
                self.status_text.setScale(scale * max_height / height)
                bounds = self.status_text.getTightBounds(self.status_panel)
                height = bounds[1].z - bounds[0].z
            self.status_text.setZ(-(bounds[0].z + bounds[1].z) / 2)
        half_height = max(0.035, height / 2 + 0.012)
        if aspect >= 0.9:
            self.status_panel.setZ(max(-0.69, -0.752 + half_height + 0.015))
        self.status_panel["frameSize"] = (
            -half_width, half_width, -half_height, half_height
        )
        self.status_accent.setPos(0, 0, -half_height)
        self.status_accent.setScale(min(1.0, half_width / 0.58), 1, 1)

    def _handle_tube_click(self, tube_index: int) -> None:
        if self.animation is not None:
            return
        self.inspected_tube = tube_index
        self.hinted_move = None
        if self.selected_tube is None:
            if not self.board[tube_index]:
                self.sound_effects.play("error")
                self.status_message = "Dieses Glas ist leer. Wähle ein gefülltes Glas."
                self._sync_hud()
                return
            self.sound_effects.play("select")
            self.selected_tube = tube_index
            self.status_message = (
                "Startglas (S) markiert. Blinkendes Z = gültiges Ziel."
            )
            self._sync_hud()
            return
        if tube_index == self.selected_tube:
            self._clear_selection()
            return

        source = self.selected_tube
        if can_pour(self.board, source, tube_index, self.capacity):
            self.history.append(self._copy_board(self.board))
            amount = min(
                top_run_length(self.board[source]),
                self.capacity - len(self.board[tube_index]),
            )
            self.animation = PourAnimation(
                source,
                tube_index,
                self.board[source][-1],
                amount,
            )
            self.sound_effects.play("pour")
            self.selected_tube = None
            self.move_count += 1
            self.status_message = "Die Flüssigkeit wird umgefüllt …"
            self._sync_hud()
            return

        self.selected_tube = tube_index if self.board[tube_index] else source
        self.sound_effects.play("error")
        self.status_message = (
            "Glas gewechselt. Wähle ein passendes Zielglas."
            if self.board[tube_index]
            else "Dorthin passt die Farbe nicht. Wähle ein anderes Glas."
        )
        self._sync_hud()

    def _show_hint(self) -> None:
        if self.animation is not None:
            return
        self.selected_tube = None
        if is_solved(self.board, self.capacity):
            self.hinted_move = None
            self.status_message = "Das Level ist bereits gelöst."
            self._sync_hud()
            return

        previous_board = self.history[-1] if self.history else None
        best_move: tuple[int, int] | None = None
        best_score: tuple[int, int, int, int, int, int] | None = None
        for source, source_tube in enumerate(self.board):
            for target in range(len(self.board)):
                if not can_pour(self.board, source, target, self.capacity):
                    continue
                amount = min(
                    top_run_length(source_tube),
                    self.capacity - len(self.board[target]),
                )
                color = source_tube[-1]
                next_board = self._copy_board(self.board)
                del next_board[source][-amount:]
                next_board[target].extend([color] * amount)
                completes_tube = (
                    len(next_board[target]) == self.capacity
                    and len(set(next_board[target])) == 1
                )
                reverses_last_move = (
                    previous_board is not None and next_board == previous_board
                )
                score = (
                    int(is_solved(next_board, self.capacity)),
                    int(completes_tube),
                    int(bool(self.board[target])),
                    int(not reverses_last_move),
                    int(not next_board[source]),
                    amount,
                )
                if best_score is None or score > best_score:
                    best_move = (source, target)
                    best_score = score

        self.hinted_move = best_move
        if best_move is None:
            self.sound_effects.play("error")
            self.status_message = "Es gibt keinen möglichen Zug."
        else:
            source, target = best_move
            self.sound_effects.play("select")
            self.status_message = (
                f"Tipp: Glas {source + 1} in Glas {target + 1} umfüllen. "
                "T = Tipp-Start, Z = Tipp-Ziel."
            )
        self._sync_hud()

    def _clear_selection(self) -> None:
        if self.selected_tube is not None:
            self.selected_tube = None
            self.sound_effects.play("select")
            self.status_message = "Auswahl aufgehoben."
            self._sync_hud()

    def _undo(self) -> None:
        if self.animation is not None:
            return
        self.hinted_move = None
        if not self.history:
            self.sound_effects.play("error")
            self.status_message = "Es gibt noch keinen Zug zum Zurücknehmen."
        else:
            self.sound_effects.play("select")
            self.board = self.history.pop()
            self.move_count = max(0, self.move_count - 1)
            self.selected_tube = None
            self.status_message = (
                "Letzter Zug zurückgenommen. Erneut drücken für weitere Züge."
            )
            self._rebuild_tubes()
        self._sync_hud()

    def _restart(self) -> None:
        self._stop_celebration()
        self.sound_effects.play("select")
        self.board = self._copy_board(self.starting_board)
        self.history.clear()
        self.move_count = 0
        self.selected_tube = None
        self.hinted_move = None
        self.animation = None
        self.status_message = "Rätsel neu gestartet."
        self._rebuild_tubes()
        self._sync_hud()

    def _next_level(self) -> None:
        if self.animation is not None:
            return
        self.sound_effects.play("select")
        self.level += 1
        save_progress(self.progress_path, self.level, self.difficulty)
        self._start_level()

    def _previous_level(self) -> None:
        if self.animation is not None:
            return
        if self.level <= 1:
            self.status_message = "Du bist bereits im ersten Level."
            self._sync_hud()
            return
        self.sound_effects.play("select")
        self.level -= 1
        save_progress(self.progress_path, self.level, self.difficulty)
        self._start_level()

    def _select_difficulty(self, difficulty: Difficulty) -> None:
        if self.animation is not None or difficulty == self.difficulty:
            return
        self.difficulty = difficulty
        self.sound_effects.play("select")
        save_progress(self.progress_path, self.level, self.difficulty)
        self._start_level()
        self.status_message = (
            f"Schwierigkeit {DIFFICULTY_LABELS[difficulty]} ausgewählt."
        )
        self._sync_hud()

    def _sync_hud(self) -> None:
        self.level_text.setText(f"LEVEL {self.level:02}")
        self.moves_text.setText(f"ZÜGE {self.move_count:02}")
        self.empty_text.setText(f"FREI {sum(not tube for tube in self.board):02}")
        self._update_difficulty_buttons()
        solved = is_solved(self.board, self.capacity)
        self._update_next_level_button(solved)
        message = "Alle Farben sind sortiert!" if solved else self.status_message
        if self.show_color_names:
            if self.inspected_tube is not None and self.inspected_tube < len(self.board):
                tube = self.board[self.inspected_tube]
                names = ", ".join(PALETTE[color][0] for color in tube) or "leer"
                message += f"\nGlas {self.inspected_tube + 1} (unten nach oben): {names}"
            else:
                message += "\nRechtsklick auf ein Glas zeigt seine Farben."
        self.status_text.setText(message)
        self._layout_status(self.getAspectRatio())
        self.status_text["fg"] = (
            (0.68, 1.0, 0.80, 1) if solved else UI_PRIMARY_TEXT_COLOR
        )
        self.status_panel["frameColor"] = (
            (0.035, 0.105, 0.070, 0.94)
            if solved
            else (0.025, 0.037, 0.050, 0.92)
        )
        self.status_accent["frameColor"] = (
            (0.25, 0.95, 0.52, 0.90)
            if solved
            else (0.10, 0.84, 0.88, 0.82)
        )
        self._update_action_button_states()
        for index, label in enumerate(self.tube_numbers):
            if index == self.selected_tube:
                label["fg"] = (1.0, 0.88, 0.55, 1)
            else:
                label["fg"] = UI_PRIMARY_TEXT_COLOR
        self._update_tube_accents()

    def _update_action_button_states(self) -> None:
        button_states = (
            bool(self.history) and self.animation is None,
            self.animation is None,
            self.animation is None,
            self.animation is None,
        )
        disabled_colors = (0.06, 0.075, 0.095, 1)
        for button, enabled in zip(self.action_buttons, button_states):
            button["state"] = DGG.NORMAL if enabled else DGG.DISABLED
            colors = button["frameColor"]
            if enabled:
                button["frameColor"] = (colors[0], colors[1], colors[2], colors[0])
            else:
                button["frameColor"] = (
                    colors[0],
                    colors[1],
                    colors[2],
                    disabled_colors,
                )

    def _update_difficulty_buttons(self) -> None:
        for difficulty, button, default_colors in zip(
            DIFFICULTIES,
            self.difficulty_buttons,
            self.difficulty_button_default_colors,
        ):
            button["frameColor"] = (
                self.difficulty_button_selected_colors
                if difficulty == self.difficulty
                else default_colors
            )

    def _update_next_level_button(self, solved: bool) -> None:
        if not solved:
            if self.next_level_button_is_blinking:
                self.next_level_button["frameColor"] = (
                    self.next_level_button_default_colors
                )
                self.next_level_button_is_blinking = False
            return

        base_color, hover_color, pressed_color = self.next_level_button_colors
        if self.reduced_motion:
            colors = (base_color, hover_color, pressed_color, base_color)
            if self.next_level_button["frameColor"] != colors:
                self.next_level_button["frameColor"] = colors
            self.next_level_button_is_blinking = True
            return

        blink_on = sin(self.ui_time * tau * 1.1) >= 0
        brightness = 1.0 if blink_on else 0.62
        base = tuple(channel * brightness for channel in base_color[:3]) + (1,)
        hover = tuple(
            min(1.0, channel * brightness) for channel in hover_color[:3]
        ) + (1,)
        pressed = pressed_color
        self.next_level_button["frameColor"] = (base, hover, pressed, base)
        self.next_level_button_is_blinking = True

    def _toggle_reduced_motion(self) -> None:
        self.reduced_motion = not self.reduced_motion
        self.motion_button["text"] = (
            "Effekte: ruhig" if self.reduced_motion else "Effekte: an"
        )
        if self.reduced_motion:
            for particle in self.celebration_particles:
                particle.node.removeNode()
            self.celebration_particles.clear()
        self.status_message = (
            "Ruhige Effekte aktiviert."
            if self.reduced_motion
            else "Bewegungseffekte aktiviert."
        )
        self._sync_hud()

    def _toggle_color_names(self) -> None:
        self.show_color_names = not self.show_color_names
        self.color_names_button["text"] = (
            "Farbnamen: an" if self.show_color_names else "Farbnamen: aus"
        )
        self._sync_hud()

    def _inspect_tube_under_pointer(self) -> None:
        if not self.show_color_names or not self.mouseWatcherNode.hasMouse():
            return
        mouse = self.mouseWatcherNode.getMouse()
        x = mouse.x * self.getAspectRatio()
        z = mouse.y
        for index, button in enumerate(self.tube_buttons):
            left, right, bottom, top = button["frameSize"]
            if (
                button.getX() + left <= x <= button.getX() + right
                and button.getZ() + bottom <= z <= button.getZ() + top
            ):
                self.inspected_tube = index
                self._sync_hud()
                return

    def _toggle_window_mode(self) -> None:
        if not isinstance(self.win, GraphicsWindow) or self.pipe is None:
            return
        if self.win.getProperties().getFullscreen():
            width = self.pipe.getDisplayWidth()
            height = self.pipe.getDisplayHeight()
            if width <= 0 or height <= 0:
                return
            window_width = min(1280, width)
            window_height = min(720, height)
            properties = WindowProperties()
            properties.setFullscreen(False)
            properties.setSize(window_width, window_height)
            properties.setOrigin(
                max(0, (width - window_width) // 2),
                max(0, (height - window_height) // 2),
            )
            self.win.requestProperties(properties)
        else:
            self._configure_fullscreen_window()

    def _start_celebration(self) -> None:
        self._stop_celebration()
        self.celebration_elapsed = 0.0
        self.celebration_text.setScale(0.075)
        self.celebration_text["fg"] = (0.58, 0.98, 0.75, 1)
        self.celebration_text.show()
        if self.reduced_motion:
            return

        aspect = self.getAspectRatio()
        for _ in range(90):
            node = self.celebration_card_model.copyTo(self.aspect2d)
            node.show()
            color = random.choice(PALETTE)[1]
            rgb = tuple(channel / 255 for channel in color)
            node.setColorScale(*rgb, 1)
            node.setPos(
                random.uniform(-aspect, aspect),
                0,
                random.uniform(0.82, 1.25),
            )
            self.celebration_particles.append(
                CelebrationParticle(
                    node=node,
                    velocity_x=random.uniform(-0.38, 0.38),
                    velocity_z=random.uniform(-0.35, -0.05),
                    spin=random.uniform(-240, 240),
                    color=rgb,
                    duration=random.uniform(2.2, 3.0),
                )
            )

    def _stop_celebration(self) -> None:
        self.celebration_elapsed = None
        self.celebration_text.hide()
        for particle in self.celebration_particles:
            particle.node.removeNode()
        self.celebration_particles.clear()

    def _update_celebration(self, delta_time: float) -> None:
        if self.celebration_elapsed is None:
            return

        self.celebration_elapsed += delta_time
        pulse = (
            1.0
            if self.reduced_motion
            else 1 + 0.045 * sin(self.celebration_elapsed * 5)
        )
        self.celebration_text.setScale(0.075 * pulse)
        alpha = max(0.0, min(1.0, (3.0 - self.celebration_elapsed) / 0.5))
        self.celebration_text["fg"] = (0.58, 0.98, 0.75, alpha)

        remaining_particles = []
        for particle in self.celebration_particles:
            particle.elapsed += delta_time
            x, _, z = particle.node.getPos()
            x += particle.velocity_x * delta_time
            z += particle.velocity_z * delta_time
            particle.velocity_z -= 0.72 * delta_time
            particle.node.setPos(x, 0, z)
            particle.node.setR(particle.node.getR() + particle.spin * delta_time)
            particle_alpha = max(0.0, 1 - particle.elapsed / particle.duration)
            particle.node.setColorScale(*particle.color, particle_alpha)
            if particle.elapsed >= particle.duration or z < -1.1:
                particle.node.removeNode()
            else:
                remaining_particles.append(particle)
        self.celebration_particles = remaining_particles

        if self.celebration_elapsed >= 3.0:
            self._stop_celebration()

    def _update_tube_accents(self) -> None:
        pulse = (
            0.5 + 0.5 * sin(self.ui_time * 2.2)
            if not self.reduced_motion
            else 0.5
        )
        blink_on = self.reduced_motion or sin(self.ui_time * tau * 1.1) >= 0
        target_source = self.selected_tube
        for index, accent in enumerate(self.tube_accents):
            finished = (
                len(self.board[index]) == self.capacity
                and len(set(self.board[index])) == 1
            )
            is_target = (
                target_source is not None
                and index != target_source
                and can_pour(self.board, target_source, index, self.capacity)
            )
            is_hinted_target = (
                self.hinted_move is not None and index == self.hinted_move[1]
            )
            if index == self.selected_tube:
                marker = "S"
            elif self.hinted_move is not None and index == self.hinted_move[0]:
                marker = "T"
            elif is_target or is_hinted_target:
                marker = "Z"
            else:
                marker = ""
            state_label = self.tube_state_labels[index]
            if state_label.getText() != marker:
                state_label.setText(marker)
            display_state = (
                "completed"
                if finished
                else "target-lit"
                if (is_target or is_hinted_target) and blink_on
                else "base"
            )
            if self.pedestal_display_states[index] != display_state:
                pedestal_material = {
                    "completed": self.completed_base_material,
                    "target-lit": self.target_base_material,
                    "base": self.base_material,
                }[display_state]
                self.pedestals[index].setMaterial(pedestal_material, 1)
                self.pedestal_display_states[index] = display_state
            led_state = (
                "success"
                if finished
                else "source"
                if index == self.selected_tube
                else "hint"
                if self.hinted_move is not None
                and index in self.hinted_move
                else "target"
                if self.selected_tube is not None
                and can_pour(self.board, self.selected_tube, index, self.capacity)
                else "idle"
            )
            if self.status_led_states[index] != led_state:
                led_color = {
                    "success": (0.12, 1.0, 0.24, 1),
                    "source": (0.02, 1.0, 0.92, 1),
                    "target": (0.05, 0.86, 1.0, 1),
                    "hint": (1.0, 0.72, 0.04, 1),
                    "idle": (0.10, 0.38, 0.88, 0.72),
                }[led_state]
                self.status_leds[index].setColorScale(*led_color)
                self.status_led_states[index] = led_state
            if index == self.selected_tube:
                alpha = 0.82 + pulse * 0.12
                accent.setColorScale(0.30, 0.92, 0.88, alpha)
                accent.setScale(1.0 + pulse * 0.025)
            elif finished:
                accent.setColorScale(0.20, 1.0, 0.35, 0.95)
                accent.setScale(1.0)
            elif self.hinted_move is not None and index == self.hinted_move[0]:
                accent.setColorScale(1.0, 0.78, 0.34, 0.9)
                accent.setScale(1.08)
            elif self.hinted_move is not None and index == self.hinted_move[1]:
                accent.setColorScale(1.0, 0.88, 0.52, 0.76)
                accent.setScale(1.04)
            elif led_state == "target":
                accent.setColorScale(0.30, 0.92, 0.88, 0.78)
                accent.setScale(1.0)
            else:
                accent.setColorScale(0.36, 0.62, 0.76, 0.2)
                accent.setScale(1.0)

    def _pour_pose(self) -> tuple[float, float, float]:
        animation = self.animation
        if animation is None:
            return 0, 0, 0
        elapsed = animation.elapsed
        if elapsed < TILT_END:
            tilt_progress = elapsed / TILT_END
            progress = tilt_progress * tilt_progress * (3 - 2 * tilt_progress)
        elif elapsed < RETURN_START:
            progress = 1
        else:
            returning = min(
                1.0,
                (elapsed - RETURN_START) / (ANIMATION_DURATION - RETURN_START),
            )
            progress = 1 - returning * returning * (3 - 2 * returning)

        centers = self._tube_centers()
        source_x, target_x = centers[animation.source], centers[animation.target]
        direction = 1 if target_x > source_x else -1
        angle = direction * 66 * progress
        radians = angle * tau / 360
        tip_x = TUBE_HEIGHT * sin(radians)
        tip_z = TUBE_HEIGHT * cos(radians)
        target_mouth_z = 3.35
        target_root_x = target_x - tip_x
        target_root_z = target_mouth_z - 0.15 - tip_z
        return (
            angle,
            source_x + (target_root_x - source_x) * progress,
            target_root_z * progress,
        )

    def _set_stream(self, visible: bool) -> None:
        if visible and not self.stream_segments:
            for _ in range(32):
                segment = self.stream_model.copyTo(self.render)
                segment.setLightOff(1)
                segment.setTransparency(TransparencyAttrib.MAlpha)
                segment.setDepthWrite(False)
                segment.setBin("transparent", 0)
                segment.hide()
                self.stream_segments.append(segment)
            self.stream_ripple = self.ripple_model.copyTo(self.render)
            self.stream_ripple.setLightOff(1)
            self.stream_ripple.setTransparency(TransparencyAttrib.MAlpha)
            self.stream_ripple.setDepthWrite(False)
            self.stream_ripple.setBin("transparent", 0)
            self.stream_ripple.hide()
        elif visible and self.stream_ripple is not None:
            self.stream_ripple.show()
        elif not visible:
            for node in self.stream_segments:
                node.hide()
            if self.stream_ripple is not None:
                self.stream_ripple.hide()

    @staticmethod
    def _orient_segment(
        node: NodePath,
        start: Point3,
        end: Point3,
        *,
        radius_scale: float = 1.0,
    ) -> None:
        delta = end - start
        length = delta.length()
        if length <= 0.001:
            node.hide()
            return
        node.show()
        node.setPos(start)
        quat = Quat()
        direction = delta / length
        axis = Vec3(0, 0, 1).cross(direction)
        if axis.lengthSquared() <= 0.000001:
            if direction.z < 0:
                quat.setFromAxisAngle(180, Vec3(1, 0, 0))
        else:
            axis.normalize()
            angle = degrees(acos(max(-1.0, min(1.0, direction.z))))
            quat.setFromAxisAngle(angle, axis)
        node.setQuat(quat)
        node.setScale(radius_scale, radius_scale, length * 1.04)

    def _update_stream(self) -> None:
        animation = self.animation
        if animation is None:
            self._set_stream(False)
            return
        elapsed = animation.elapsed
        fade_in = min(
            1.0,
            max(0.0, (elapsed - TILT_END) / STREAM_FADE_DURATION),
        )
        fade_out = min(
            1.0,
            max(0.0, (STREAM_END - elapsed) / STREAM_FADE_DURATION),
        )
        alpha = min(fade_in, fade_out)
        self._set_stream(alpha > 0)
        if alpha <= 0:
            return

        source = self.vessel_roots[animation.source]
        direction = (
            1
            if self._tube_centers()[animation.target]
            > self._tube_centers()[animation.source]
            else -1
        )
        start = source.getMat(self.render).xformPoint(
            Point3(direction * 0.38, 0, TUBE_HEIGHT - 0.08)
        )
        end = self._liquid_surface_point(animation.target)
        control_1 = start + Vec3(direction * 0.12, 0, -0.08)
        control_2 = end + Vec3(direction * 0.04, 0, 0.18)

        def point_at(t: float) -> Point3:
            inv = 1 - t
            point = (
                start * (inv * inv * inv)
                + control_1 * (3 * inv * inv * t)
                + control_2 * (3 * inv * t * t)
                + end * (t * t * t)
            )
            point.x += sin(elapsed * 4.2 - t * 2.4) * sin(t * pi) * 0.012
            return point

        segment_count = len(self.stream_segments)
        points = [
            point_at(index / segment_count)
            for index in range(segment_count + 1)
        ]
        for index, node in enumerate(self.stream_segments):
            fraction = (index + 0.5) / segment_count
            radius = (
                1.14
                - 0.34 * fraction
                + 0.018 * sin(elapsed * 8 - fraction * 5)
            )
            self._orient_segment(
                node,
                points[index],
                points[index + 1],
                radius_scale=radius,
            )
            rgb = PALETTE[animation.color][1]
            node.setColorScale(
                rgb[0] / 255,
                rgb[1] / 255,
                rgb[2] / 255,
                alpha * 0.9,
            )

        if self.stream_ripple is not None:
            ripple_phase = (elapsed * 1.8) % 1.0
            ripple_fade = sin(ripple_phase * pi)
            surface = self._liquid_surface_point(animation.target)
            self.stream_ripple.setPos(surface.x, surface.y, surface.z + 0.008)
            self.stream_ripple.setScale(0.65 + ripple_phase * 0.85)
            self.stream_ripple.setColorScale(
                min(1.0, rgb[0] / 255 + 0.25),
                min(1.0, rgb[1] / 255 + 0.25),
                min(1.0, rgb[2] / 255 + 0.25),
                alpha * ripple_fade * 0.55,
            )

    def _update(self, task: Any) -> int:
        self._sync_window_mode()
        delta_time = min(ClockObject.getGlobalClock().getDt(), 0.05)
        self.ui_time += delta_time
        self._update_tube_accents()
        self._update_next_level_button(is_solved(self.board, self.capacity))
        self._update_celebration(delta_time)
        animation = self.animation
        if animation is None:
            return task.cont
        animation.elapsed = min(
            ANIMATION_DURATION,
            animation.elapsed + delta_time * 2,
        )

        angle, x, z = self._pour_pose()
        source_index = animation.source
        vessel = self.vessel_roots[source_index]
        source_center = self._tube_centers()[source_index]
        vessel.setX(x - source_center)
        vessel.setZ(0.13 + z)
        rotation = Quat()
        rotation.setFromAxisAngle(angle, Vec3(0, 1, 0))
        vessel.setQuat(rotation)

        self._update_liquid(animation.source)
        self._update_liquid(animation.target)
        self._update_liquid_surface_motion(animation)
        self._update_stream()
        if animation.elapsed >= ANIMATION_DURATION:
            pour(self.board, animation.source, animation.target, self.capacity)
            self.animation = None
            self._set_stream(False)
            self._rebuild_tubes()
            solved = is_solved(self.board, self.capacity)
            if solved:
                save_progress(self.progress_path, self.level, self.difficulty)
                self.sound_effects.play("success")
                self._start_celebration()
            elif (
                len(self.board[animation.target]) == self.capacity
                and len(set(self.board[animation.target])) == 1
            ):
                self.sound_effects.play("success")
            self.status_message = (
                "Geschafft! Alle Farben sind sortiert."
                if solved
                else "Gut gemacht! Der nächste Zug wartet."
            )
            self._sync_hud()
        return task.cont

    def _update_liquid_surface_motion(self, animation: PourAnimation) -> None:
        transfer_progress = min(
            1.0,
            max(
                0.0,
                (animation.elapsed - POUR_START) / (POUR_END - POUR_START),
            ),
        )
        motion = sin(transfer_progress * pi)
        for index in (animation.source, animation.target):
            surface = self.liquid_surfaces[index]
            phase = animation.elapsed * (11 if index == animation.target else 8)
            amount = motion * (2.2 if index == animation.target else 1.4)
            surface.setHpr(
                0,
                sin(phase) * amount,
                cos(phase * 0.82) * amount * 0.75,
            )


def run_3d_game() -> None:
    game = Panda3DColorSortGame()
    game.run()
