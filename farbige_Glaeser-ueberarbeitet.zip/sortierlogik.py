import random

Tube = list[int]
Board = list[Tube]


def top_run_length(tube: Tube) -> int:
    if not tube:
        return 0

    color = tube[-1]
    count = 0
    for item in reversed(tube):
        if item != color:
            break
        count += 1
    return count


def can_pour(board: Board, source: int, target: int, capacity: int = 4) -> bool:
    if not 0 <= source < len(board) or not 0 <= target < len(board):
        return False
    if source == target or not board[source] or len(board[target]) >= capacity:
        return False

    return not board[target] or board[target][-1] == board[source][-1]


def pour(board: Board, source: int, target: int, capacity: int = 4) -> int:
    if not can_pour(board, source, target, capacity):
        raise ValueError("Diese Flüssigkeit kann nicht umgefüllt werden.")

    source_tube = board[source]
    target_tube = board[target]
    amount = min(
        top_run_length(source_tube),
        capacity - len(target_tube),
    )
    color = source_tube[-1]
    del source_tube[-amount:]
    target_tube.extend([color] * amount)
    return amount


def is_solved(board: Board, capacity: int = 4) -> bool:
    return all(
        not tube or (len(tube) == capacity and len(set(tube)) == 1)
        for tube in board
    )


def create_puzzle(
    color_count: int,
    empty_tubes: int = 2,
    capacity: int = 4,
    scramble_steps: int = 80,
    seed: int | None = None,
    max_scramble_pour: int | None = None,
) -> Board:
    if color_count < 1:
        raise ValueError("Es wird mindestens eine Farbe benötigt.")
    if empty_tubes < 1:
        raise ValueError("Mindestens ein leeres Reagenzglas wird benötigt.")
    if capacity < 2:
        raise ValueError("Ein Reagenzglas muss mindestens zwei Plätze haben.")
    if scramble_steps < 0:
        raise ValueError("Die Anzahl der Mischschritte darf nicht negativ sein.")
    if max_scramble_pour is not None and max_scramble_pour < 1:
        raise ValueError("Die maximale Mischmenge muss mindestens eins betragen.")

    rng = random.Random(seed)
    board = [[color] * capacity for color in range(color_count)]
    board.extend([] for _ in range(empty_tubes))

    for _ in range(scramble_steps):
        choices: list[tuple[int, int, int]] = []
        for source, tube in enumerate(board):
            if not tube:
                continue

            color = tube[-1]
            group_size = top_run_length(tube)
            for target, receiving_tube in enumerate(board):
                if target == source or (
                    receiving_tube and receiving_tube[-1] == color
                ):
                    continue

                # Each reverse step undoes a legal pour, so the puzzle stays solvable.
                max_amount = group_size
                if group_size < len(tube):
                    max_amount -= 1
                max_amount = min(max_amount, capacity - len(receiving_tube))
                if max_scramble_pour is not None:
                    max_amount = min(max_amount, max_scramble_pour)
                if max_amount > 0:
                    choices.append((source, target, max_amount))

        if not choices:
            break

        source, target, max_amount = rng.choice(choices)
        amount = rng.randint(1, max_amount)
        color = board[source][-1]
        del board[source][-amount:]
        board[target].extend([color] * amount)

    if scramble_steps and is_solved(board, capacity):
        source = next(index for index, tube in enumerate(board) if len(tube) == capacity)
        target = next(index for index, tube in enumerate(board) if not tube)
        board[target].append(board[source].pop())

    return board
