import json
import os
from pathlib import Path
import sys
from typing import Literal, TypeGuard
import warnings

Difficulty = Literal["leicht", "mittel", "schwer"]
DIFFICULTIES: tuple[Difficulty, ...] = ("leicht", "mittel", "schwer")
DEFAULT_DIFFICULTY: Difficulty = "mittel"


def progress_file_path() -> Path:
    if sys.platform == "win32":
        local_app_data = os.environ.get("LOCALAPPDATA")
        if local_app_data:
            return Path(local_app_data) / "Farb-Labor" / "progress.json"
        return Path.home() / "AppData" / "Local" / "Farb-Labor" / "progress.json"

    data_home = os.environ.get("XDG_DATA_HOME")
    if data_home:
        return Path(data_home) / "Farb-Labor" / "progress.json"
    return Path.home() / ".local" / "share" / "Farb-Labor" / "progress.json"


def _is_difficulty(value: object) -> TypeGuard[Difficulty]:
    return isinstance(value, str) and value in DIFFICULTIES


def load_progress(path: Path) -> tuple[int, Difficulty]:
    try:
        contents = path.read_text(encoding="utf-8")
    except FileNotFoundError:
        return 1, DEFAULT_DIFFICULTY
    except OSError as error:
        warnings.warn(
            f"Levelstand konnte nicht gelesen werden: {error}",
            stacklevel=2,
        )
        return 1, DEFAULT_DIFFICULTY

    try:
        data = json.loads(contents)
    except json.JSONDecodeError as error:
        warnings.warn(f"Levelstand ist ungültig: {error}", stacklevel=2)
        return 1, DEFAULT_DIFFICULTY

    level = data.get("level") if isinstance(data, dict) else None
    if type(level) is not int or level < 1:
        warnings.warn("Levelstand enthält kein gültiges Level.", stacklevel=2)
        level = 1

    difficulty = (
        data.get("difficulty", DEFAULT_DIFFICULTY)
        if isinstance(data, dict)
        else None
    )
    if not _is_difficulty(difficulty):
        warnings.warn("Levelstand enthält keine gültige Schwierigkeit.", stacklevel=2)
        difficulty = DEFAULT_DIFFICULTY
    return level, difficulty


def load_level(path: Path) -> int:
    return load_progress(path)[0]


def _save_progress_data(path: Path, data: dict[str, int | str]) -> None:
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(
            json.dumps(data, ensure_ascii=False),
            encoding="utf-8",
        )
    except OSError as error:
        warnings.warn(
            f"Levelstand konnte nicht gespeichert werden: {error}",
            stacklevel=2,
        )


def save_level(path: Path, level: int) -> None:
    if type(level) is not int or level < 1:
        raise ValueError("Das gespeicherte Level muss eine positive Ganzzahl sein.")

    _save_progress_data(path, {"level": level})


def save_progress(path: Path, level: int, difficulty: Difficulty) -> None:
    if type(level) is not int or level < 1:
        raise ValueError("Das gespeicherte Level muss eine positive Ganzzahl sein.")
    if not _is_difficulty(difficulty):
        raise ValueError("Die gespeicherte Schwierigkeit ist ungültig.")

    _save_progress_data(path, {"level": level, "difficulty": difficulty})
