def main() -> None:
    from panda3d_game import run_3d_game

    run_3d_game()


if __name__ == "__main__":
    main()
