import json
from pathlib import Path
import tempfile
import unittest
import warnings

from game_progress import load_level, load_progress, save_level, save_progress


class GameProgressTests(unittest.TestCase):
    def setUp(self) -> None:
        self.directory = tempfile.TemporaryDirectory()
        self.path = Path(self.directory.name) / "progress.json"

    def tearDown(self) -> None:
        self.directory.cleanup()

    def test_missing_progress_starts_at_level_one(self) -> None:
        self.assertEqual(load_level(self.path), 1)
        self.assertEqual(load_progress(self.path), (1, "mittel"))

    def test_saves_and_loads_level(self) -> None:
        save_level(self.path, 7)
        saved_data = json.loads(self.path.read_text(encoding="utf-8"))
        self.assertEqual(saved_data, {"level": 7})
        self.assertEqual(load_level(self.path), 7)

    def test_saves_and_loads_difficulty_with_the_level(self) -> None:
        save_progress(self.path, 4, "schwer")

        self.assertEqual(
            json.loads(self.path.read_text(encoding="utf-8")),
            {"level": 4, "difficulty": "schwer"},
        )
        self.assertEqual(load_progress(self.path), (4, "schwer"))

    def test_existing_progress_defaults_to_medium_difficulty(self) -> None:
        self.path.write_text('{"level": 3}', encoding="utf-8")

        self.assertEqual(load_progress(self.path), (3, "mittel"))

    def test_invalid_progress_warns_and_starts_at_level_one(self) -> None:
        self.path.write_text('{"level": 0}', encoding="utf-8")
        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter("always")
            self.assertEqual(load_level(self.path), 1)
        self.assertEqual(len(caught), 1)
