# Farb-Labor

## Start unter Windows

Python 3 installieren und im Projektordner ausführen:

```powershell
py -m pip install panda3d pygame
py main.py
```

## Bedienung

- Mit der linken Maustaste ein Startglas und anschließend ein Zielglas wählen.
- **Farbnamen** einschalten und mit der rechten Maustaste ein Glas untersuchen:
  Die Farbnamen erscheinen im Statusfeld von unten nach oben. Ein Linksklick
  zeigt ebenfalls die Farben des zuletzt angeklickten Glases.
- **Effekte: ruhig** reduziert blinkende und bewegte Effekte. Die Umschalttaste
  `M` funktioniert weiterhin.
- **Fenster** beziehungsweise **Vollbild** wechselt den Anzeigemodus; alternativ
  kann `F` verwendet werden. `C` schaltet die Farbnamen um.
- `H` zeigt einen Tipp, `U` nimmt einen Zug zurück, `R` startet das Rätsel neu,
  `N` öffnet das nächste Level und `Q` beendet das Spiel.

Der Spielstand liegt außerhalb des Projektordners unter
`%LOCALAPPDATA%\Farb-Labor\progress.json`.
