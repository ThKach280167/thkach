from colorsys import rgb_to_hsv
import os
from pathlib import Path
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import call, patch

from panda3d.core import LColor, PNMImage, Point2, Point3, WindowProperties, loadPrcFileData

from game_progress import load_progress
from sortierlogik import is_solved

os.environ.setdefault("SDL_AUDIODRIVER", "dummy")

loadPrcFileData(
    "Farb-Labor 3D tests",
    "window-type offscreen\nfullscreen false\nsync-video false",
)

from panda3d_game import (
    ANIMATION_DURATION,
    CAPACITY,
    DIFFICULTY_SETTINGS,
    GLASS_PROFILE,
    POUR_START,
    POUR_END,
    RETURN_START,
    STREAM_END,
    PALETTE,
    Panda3DColorSortGame,
    UI_BOLD_FONT_PATHS,
    UI_FONT_PIXELS_PER_UNIT,
    UI_FONT_RENDER_MODE,
    UI_HINT_BUTTON_TEXT_COLOR,
    UI_PRIMARY_TEXT_COLOR,
    UI_SECONDARY_TEXT_COLOR,
)


class _TaskStub:
    cont = 1


class Panda3DGameTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.game = Panda3DColorSortGame()
        cls.progress_directory = tempfile.TemporaryDirectory()
        cls.game.progress_path = Path(cls.progress_directory.name) / "progress.json"
        cls.game.difficulty = "mittel"
        cls.game.level = 1
        cls.game._start_level()

    @classmethod
    def tearDownClass(cls) -> None:
        cls.game.destroy()
        cls.progress_directory.cleanup()

    def setUp(self) -> None:
        self.game._stop_celebration()
        self.game.reduced_motion = False
        self.game.show_color_names = False
        self.game.color_names_button["text"] = "Farbnamen: aus"
        self.game.motion_button["text"] = "Effekte: an"
        self.game.animation = None
        self.game.selected_tube = None
        self.game.hinted_move = None
        self.game._set_stream(False)
        self.game.difficulty = "mittel"
        self.game.level = 1
        self.game._start_level()

    def _render_viewport_screenshot(self, width: int, height: int) -> PNMImage:
        aspect = width / height
        image = PNMImage()
        output = self.game.win.makeTextureBuffer(
            f"visual-test-{width}x{height}",
            width,
            height,
        )
        self.assertIsNotNone(output)
        if output is None:
            self.fail("Panda3D could not create the requested visual-test buffer.")

        original_aspect_scale = self.game.aspect2d.getSx()
        original_lens_aspect = self.game.camLens.getAspectRatio()
        try:
            output.setClearColor(LColor(0.007, 0.009, 0.013, 1))
            output.setClearColorActive(True)
            output.setClearDepthActive(True)
            world_region = output.makeDisplayRegion()
            world_region.setCamera(self.game.cam)
            ui_region = output.makeDisplayRegion()
            ui_region.setSort(10)
            ui_region.setCamera(self.game.cam2d)

            self.game.aspect2d.setSx(1 / aspect)
            with patch.object(self.game, "getAspectRatio", return_value=aspect):
                self.game._resize_controls()
            self.game.graphicsEngine.renderFrame()
            self.game.graphicsEngine.renderFrame()
            self.assertTrue(output.getScreenshot(image))
            return image
        finally:
            self.game.graphicsEngine.removeWindow(output)
            self.game.aspect2d.setSx(original_aspect_scale)
            self.game.camLens.setAspectRatio(original_lens_aspect)
            self.game._resize_controls()

    def test_builds_real_3d_tubes_and_color_materials(self) -> None:
        self.assertEqual(len(self.game.tube_roots), len(self.game.board))
        self.assertEqual(len(self.game.liquid_models), 9)
        self.assertFalse(self.game.render.find("**/large soft key light").isEmpty())
        self.assertGreater(self.game.vessel_model.node().getNumGeoms(), 0)

    def test_glass_and_liquid_surfaces_use_depth_sorted_transparency(self) -> None:
        glass = self.game.vessel_roots[0].find("**/thick walled rounded test tube")
        surface = self.game.liquid_surfaces[0]

        self.assertEqual(glass.getBinName(), "transparent")
        self.assertEqual(surface.getBinName(), "transparent")

    def test_pedestals_have_beveled_meshes_and_status_lights(self) -> None:
        pedestal_geom = self.game.pedestals[0].node().getGeom(0)
        self.assertEqual(pedestal_geom.getVertexData().getNumRows(), 56)
        self.assertEqual(len(self.game.status_leds), len(self.game.board))
        self.assertTrue(self.game.status_leds[0].hasLightOff())

    def test_tubes_have_satin_collars_and_tiered_pedestal_feet(self) -> None:
        self.assertEqual(len(self.game.pedestal_feet), len(self.game.board))
        self.assertEqual(len(self.game.vessel_trims), len(self.game.board) * 2)
        self.assertTrue(all(
            trim.getMaterial() == self.game.glass_trim_material
            for trim in self.game.vessel_trims
        ))
        self.assertAlmostEqual(self.game.vessel_trims[0].getSx(), 0.83, places=6)
        self.assertAlmostEqual(self.game.vessel_trims[1].getSx(), 1.18, places=6)

    def test_narrow_window_reflows_controls_without_distorting_them(self) -> None:
        original_scale = self.game.action_buttons[0].getSx()
        self.addCleanup(self.game._resize_controls)

        with patch.object(self.game, "getAspectRatio", return_value=0.40):
            self.game._resize_controls()

        self.assertLess(self.game.action_buttons[0].getSx(), original_scale)
        self.assertAlmostEqual(
            self.game.action_buttons[0].getSx(), self.game.action_buttons[0].getSz()
        )
        self.assertFalse(hasattr(self.game, "help_text"))
        self.assertEqual(
            self.game.action_buttons[0].getZ(),
            self.game.action_buttons[1].getZ(),
        )
        self.assertNotEqual(
            self.game.action_buttons[0].getZ(),
            self.game.action_buttons[2].getZ(),
        )

    def test_screenshot_layouts_render_and_controls_stay_inside_wide_and_portrait_views(
        self,
    ) -> None:
        self.game.difficulty = "schwer"
        self.game.level = 1
        self.game._start_level()
        self.game.board = [
            [0],
            [1],
            [2],
            [3],
            [4],
            [5],
            [6],
            [7],
            [8],
            [],
        ]
        self.game._rebuild_tubes()
        self.game._handle_tube_click(0)

        for width, height in ((1600, 900), (720, 1280), (300, 1000)):
            aspect = width / height
            with self.subTest(viewport=(width, height)):
                with patch.object(self.game, "getAspectRatio", return_value=aspect):
                    self.game._resize_controls()
                for button in (
                    *self.game.level_buttons,
                    *self.game.difficulty_buttons,
                    *self.game.action_buttons,
                    *self.game.utility_buttons,
                ):
                    left = button.getX() + button["frameSize"][0] * button.getSx()
                    right = button.getX() + button["frameSize"][1] * button.getSx()
                    self.assertGreaterEqual(left, -aspect)
                    self.assertLessEqual(right, aspect)
                for label in (
                    self.game.title_text,
                    self.game.subtitle_text,
                    self.game.status_text,
                    self.game.difficulty_text,
                    *self.game.tube_numbers,
                    *self.game.tube_state_labels,
                ):
                    bounds = label.getTightBounds(self.game.aspect2d)
                    if bounds is not None:
                        self.assertGreaterEqual(bounds[0][0], -aspect)
                        self.assertLessEqual(bounds[1][0], aspect)
                        self.assertGreaterEqual(bounds[0][2], -1)
                        self.assertLessEqual(bounds[1][2], 1)
                self.assertEqual(self.game.tube_state_labels[0].getText(), "S")
                self.assertIn(
                    "Z",
                    [label.getText() for label in self.game.tube_state_labels],
                )

                screenshot = self._render_viewport_screenshot(width, height)
                self.assertEqual(screenshot.getXSize(), width)
                self.assertEqual(screenshot.getYSize(), height)
                sample_step = max(1, min(width, height) // 180)
                lit_samples = 0
                for x in range(0, width, sample_step):
                    for y in range(0, height, sample_step):
                        pixel = screenshot.getXel(x, y)
                        if max(pixel[0], pixel[1], pixel[2]) > 0.12:
                            lit_samples += 1
                self.assertGreater(lit_samples, 100)

    def test_controls_do_not_overlap_at_narrow_or_wide_aspects(self) -> None:
        self.addCleanup(self.game._resize_controls)
        for aspect in (0.30, 0.5625, 0.899, 0.9, 16 / 9):
            with self.subTest(aspect=aspect):
                with patch.object(self.game, "getAspectRatio", return_value=aspect):
                    self.game._resize_controls()
                buttons = self.game.action_buttons + self.game.utility_buttons
                rectangles = []
                for button in buttons:
                    left, right, bottom, top = button["frameSize"]
                    rectangles.append((
                        button.getX() + left * button.getSx(),
                        button.getX() + right * button.getSx(),
                        button.getZ() + bottom * button.getSz(),
                        button.getZ() + top * button.getSz(),
                    ))
                for index, first in enumerate(rectangles):
                    self.assertGreaterEqual(first[0], -aspect)
                    self.assertLessEqual(first[1], aspect)
                    self.assertGreaterEqual(first[2], -1)
                    self.assertLessEqual(first[3], 1)
                    for second in rectangles[index + 1:]:
                        overlap_x = min(first[1], second[1]) - max(first[0], second[0])
                        overlap_z = min(first[3], second[3]) - max(first[2], second[2])
                        self.assertFalse(overlap_x > 1e-6 and overlap_z > 1e-6)

    def test_compact_header_reflows_and_restores_wide_layout(self) -> None:
        self.addCleanup(self.game._resize_controls)
        with patch.object(self.game, "getAspectRatio", return_value=0.3):
            self.game._resize_controls()
        self.assertAlmostEqual(self.game.stat_panels[0].getX(), 0)
        self.assertGreater(
            self.game.stat_panels[0].getZ(), self.game.stat_panels[1].getZ()
        )
        bounds = self.game.level_text.getTightBounds(self.game.aspect2d)
        left, right = self.game.level_buttons
        self.assertLess(left.getX() + left["frameSize"][1] * left.getSx(), bounds[0].x)
        self.assertGreater(right.getX() + right["frameSize"][0] * right.getSx(), bounds[1].x)
        with patch.object(self.game, "getAspectRatio", return_value=16 / 9):
            self.game._resize_controls()
        self.assertEqual(self.game.stat_panels[0].getZ(), self.game.stat_panels[1].getZ())
        self.assertLess(self.game.stat_panels[0].getX(), self.game.stat_panels[1].getX())

    def test_status_wraps_and_stays_inside_its_panel(self) -> None:
        self.game.board = [[0, 1, 2, 3, 4, 5], []]
        self.game._rebuild_tubes()
        self.game._toggle_color_names()
        self.game._handle_tube_click(0)
        self.addCleanup(self.game._resize_controls)
        for aspect in (0.30, 0.5625, 16 / 9):
            with self.subTest(aspect=aspect):
                with patch.object(self.game, "getAspectRatio", return_value=aspect):
                    self.game._resize_controls()
                bounds = self.game.status_text.getTightBounds(self.game.status_panel)
                self.assertIsNotNone(bounds)
                left, right, bottom, top = self.game.status_panel["frameSize"]
                self.assertGreaterEqual(bounds[0].x, left)
                self.assertLessEqual(bounds[1].x, right)
                self.assertGreaterEqual(bounds[0].z, bottom)
                self.assertLessEqual(bounds[1].z, top)
                self.assertGreater(self.game.status_text.textNode.getNumRows(), 1)
                panel_bottom = self.game.status_panel.getZ() + bottom
                action_top = (
                    self.game.action_panel.getZ()
                    + self.game.action_panel["frameSize"][3]
                )
                self.assertGreater(panel_bottom, action_top)

    def test_optional_color_names_describe_each_layer_and_empty_glasses(self) -> None:
        self.game.board = [[0, 2, 3], [], [6]]
        self.game._rebuild_tubes()
        self.game._toggle_color_names()
        self.game._handle_tube_click(0)
        self.assertIn("Glas 1 (unten nach oben): Koralle, Sonnengelb, Grün",
                      self.game.status_text.getText())
        self.game._clear_selection()
        self.game._handle_tube_click(1)
        self.assertIn("Glas 2 (unten nach oben): leer", self.game.status_text.getText())
        self.game._toggle_color_names()
        self.assertNotIn("unten nach oben", self.game.status_text.getText())
        self.assertEqual(self.game.color_names_button["text"], "Farbnamen: aus")

    def test_right_click_inspects_colors_without_playing_a_move(self) -> None:
        self.game.board = [[0, 2], [3], []]
        self.game._rebuild_tubes()
        self.game._toggle_color_names()
        button = self.game.tube_buttons[1]
        mouse = SimpleNamespace(
            hasMouse=lambda: True,
            getMouse=lambda: Point2(
                button.getX() / self.game.getAspectRatio(), button.getZ()
            ),
        )
        with patch.object(self.game, "mouseWatcherNode", mouse):
            self.game._inspect_tube_under_pointer()
        self.assertIn("Glas 2 (unten nach oben): Grün", self.game.status_text.getText())
        self.assertIsNone(self.game.selected_tube)
        self.assertEqual(self.game.board, [[0, 2], [3], []])

    def test_window_toggle_uses_actual_window_state(self) -> None:
        class FakeWindow:
            def __init__(self) -> None:
                self.properties = WindowProperties()
                self.properties.setFullscreen(True)

            def getProperties(self):
                return self.properties

            def requestProperties(self, properties):
                self.properties = properties

        window = FakeWindow()
        pipe = SimpleNamespace(getDisplayWidth=lambda: 1600,
                               getDisplayHeight=lambda: 900)
        self.addCleanup(setattr, self.game, "fullscreen_mode", self.game.fullscreen_mode)
        with patch("panda3d_game.GraphicsWindow", FakeWindow), \
             patch.object(self.game, "win", window), \
             patch.object(self.game, "pipe", pipe):
            self.game.fullscreen_mode = True
            self.game._toggle_window_mode()
            self.game._sync_window_mode()
            self.assertFalse(window.properties.getFullscreen())
            self.assertEqual(window.properties.getXSize(), 1280)
            self.assertEqual(window.properties.getYSize(), 720)
            self.assertEqual(self.game.window_button["text"], "Vollbild")
            self.game._toggle_window_mode()
            self.game._sync_window_mode()
            self.assertTrue(window.properties.getFullscreen())
            self.assertEqual(self.game.window_button["text"], "Fenster")

    def test_selection_and_hint_have_non_color_state_markers(self) -> None:
        self.game.board = [[0, 0], [0], [], []]
        self.game._rebuild_tubes()

        self.game._handle_tube_click(0)
        self.assertEqual(
            [label.getText() for label in self.game.tube_state_labels],
            ["S", "Z", "Z", "Z"],
        )
        self.assertIn("S", self.game.status_text.getText())
        self.assertIn("Z", self.game.status_text.getText())

        self.game._clear_selection()
        self.game._show_hint()
        assert self.game.hinted_move is not None
        source, target = self.game.hinted_move
        self.assertEqual(self.game.tube_state_labels[source].getText(), "T")
        self.assertEqual(self.game.tube_state_labels[target].getText(), "Z")
        self.assertIn("T = Tipp-Start", self.game.status_text.getText())

    def test_tube_click_targets_follow_projection_without_overlapping(self) -> None:
        self.game.board = [[index % 9] for index in range(10)]
        self.game._rebuild_tubes()
        self.addCleanup(self.game._resize_controls)
        radius = max(radius for radius, _ in GLASS_PROFILE)
        heights = (min(height for _, height in GLASS_PROFILE),
                   max(height for _, height in GLASS_PROFILE))
        for aspect in (0.30, 0.5625, 16 / 9):
            with self.subTest(aspect=aspect):
                with patch.object(self.game, "getAspectRatio", return_value=aspect):
                    self.game._resize_controls()
                for vessel, button in zip(self.game.vessel_roots, self.game.tube_buttons):
                    left, right, bottom, top = button["frameSize"]
                    projected_x = []
                    for height in heights:
                        for x in (-radius, radius):
                            point = Point3()
                            camera_point = self.game.cam.getRelativePoint(
                                vessel, Point3(x, 0, height)
                            )
                            self.assertTrue(self.game.camLens.project(camera_point, point))
                            projected_x.append(point.x * aspect)
                            self.assertGreaterEqual(point.y, button.getZ() + bottom - 1e-6)
                            self.assertLessEqual(point.y, button.getZ() + top + 1e-6)
                    self.assertGreaterEqual(
                        right - left, (max(projected_x) - min(projected_x)) * 0.7
                    )
                for left_button, right_button in zip(
                    self.game.tube_buttons, self.game.tube_buttons[1:]
                ):
                    self.assertLess(
                        left_button.getX() + left_button["frameSize"][1],
                        right_button.getX() + right_button["frameSize"][0],
                    )

    def test_glasses_have_no_added_vertical_reflection_strips(self) -> None:
        for vessel in self.game.vessel_roots:
            self.assertTrue(
                vessel.findAllMatches("**/raised glass reflection").isEmpty()
            )

    def test_completed_tube_pedestal_is_green_and_resets_when_incomplete(self) -> None:
        self.game.board = [[2, 2, 2, 2], [2, 2, 2], [], []]
        self.game._rebuild_tubes()

        completed_material = self.game.pedestals[0].getMaterial()
        self.assertIsNotNone(completed_material)
        assert completed_material is not None
        diffuse = completed_material.getDiffuse()
        self.assertGreater(diffuse[1], diffuse[0] * 2)
        self.assertGreater(diffuse[1], diffuse[2] * 1.5)
        self.assertEqual(self.game.pedestals[1].getMaterial(), self.game.base_material)

        self.game.board[0].pop()
        self.game._update_tube_accents()
        self.assertEqual(self.game.pedestals[0].getMaterial(), self.game.base_material)

    def test_glossy_liquid_surface_follows_fill_and_moves_during_pour(self) -> None:
        self.game.board = [[0, 0], [0], [], []]
        self.game._rebuild_tubes()
        source_surface = self.game.liquid_surfaces[0]
        target_surface = self.game.liquid_surfaces[1]
        empty_surface = self.game.liquid_surfaces[2]

        self.assertFalse(source_surface.isHidden())
        self.assertFalse(target_surface.isHidden())
        self.assertTrue(empty_surface.isHidden())
        self.assertGreater(source_surface.getZ(), target_surface.getZ())

        self.game._handle_tube_click(0)
        self.game._handle_tube_click(1)
        assert self.game.animation is not None
        self.game.animation.elapsed = 1.0
        self.game._update_liquid_surface_motion(self.game.animation)

        self.assertTrue(
            any(abs(angle) > 0.01 for angle in target_surface.getHpr())
        )

    def test_green_and_blue_are_distinct(self) -> None:
        green = PALETTE[3][1]
        blue = PALETTE[1][1]
        green_hue = rgb_to_hsv(*(channel / 255 for channel in green))[0]
        blue_hue = rgb_to_hsv(*(channel / 255 for channel in blue))[0]
        hue_distance = abs(green_hue - blue_hue)
        rgb_distance = sum(
            (green_channel - blue_channel) ** 2
            for green_channel, blue_channel in zip(green, blue)
        ) ** 0.5

        self.assertGreater(min(hue_distance, 1 - hue_distance), 0.25)
        self.assertGreater(rgb_distance, 150)

    def test_solved_status_is_displayed_once_in_readable_text(self) -> None:
        self.game.board = [[0, 0, 0, 0], [1, 1, 1, 1], [], []]
        self.game._rebuild_tubes()
        self.game._sync_hud()

        self.assertEqual(self.game.status_text.getText(), "Alle Farben sind sortiert!")
        self.assertGreater(self.game.status_text.getScale()[0], 0.04)
        self.assertIsNotNone(self.game.ui_font)

    def test_hud_labels_and_controls_use_readable_sizes_and_contrast(self) -> None:
        for label in (
            self.game.level_text,
            self.game.moves_text,
            self.game.empty_text,
        ):
            self.assertGreaterEqual(label.getScale()[0], 0.036)
        self.assertIn("LEVEL", self.game.level_text.getText())
        self.assertIn("ZÜGE", self.game.moves_text.getText())
        self.assertIn("FREI", self.game.empty_text.getText())
        self.assertFalse(hasattr(self.game, "help_text"))
        self.assertGreaterEqual(self.game.difficulty_text.getScale()[0], 0.025)
        self.assertIsNotNone(self.game.ui_font)
        self.assertEqual(
            self.game.ui_font.getRenderMode(),
            UI_FONT_RENDER_MODE,
        )
        self.assertEqual(
            self.game.ui_font.getPixelsPerUnit(),
            UI_FONT_PIXELS_PER_UNIT,
        )
        self.assertTrue(self.game.ui_font.getNativeAntialias())
        self.assertIn(self.game.ui_font_path, UI_BOLD_FONT_PATHS)
        for label in (
            self.game.level_text,
            self.game.status_text,
        ):
            self.assertEqual(label.getFont(), self.game.ui_font)
        for button in self.game.action_buttons:
            self.assertEqual(button["text_font"], self.game.ui_font)
        self.assertGreaterEqual(min(UI_PRIMARY_TEXT_COLOR[:3]), 0.95)
        self.assertGreaterEqual(min(UI_SECONDARY_TEXT_COLOR[:3]), 0.90)
        self.assertLess(
            max(UI_HINT_BUTTON_TEXT_COLOR[:3]),
            0.15,
        )
        self.assertGreaterEqual(
            self.game.action_buttons[0]["text_scale"][0],
            0.040,
        )
        self.assertTrue(
            all(panel.getBinName() == "fixed" for panel in self.game.stat_panels)
        )
        self.assertEqual(self.game.moves_text.getBinName(), "fixed")

    def test_refined_hud_accents_follow_the_responsive_panels(self) -> None:
        self.assertIn(self.game.ui_font_path, UI_BOLD_FONT_PATHS)
        self.assertEqual(len(self.game.stat_panel_accents), len(self.game.stat_panels))
        self.assertTrue(
            all(
                accent.getBinName() == "fixed"
                for accent in self.game.stat_panel_accents
            )
        )
        self.assertEqual(self.game.action_panel_accent.getBinName(), "fixed")

        with patch.object(self.game, "getAspectRatio", return_value=0.65):
            self.game._resize_controls()

        for accent, panel in zip(
            self.game.stat_panel_accents,
            self.game.stat_panels,
        ):
            self.assertAlmostEqual(accent.getX(), panel.getX())
            self.assertEqual(accent.getSx(), panel.getSx())

    def test_synthesized_game_sounds_are_available(self) -> None:
        self.assertTrue(self.game.sound_effects.available)
        for effect, sound in self.game.sound_effects._sounds.items():
            self.assertGreater(sound.get_length(), 0)
            self.game.sound_effects.play(effect)

    def test_selecting_and_pouring_play_their_matching_sounds(self) -> None:
        self.game.board = [[0, 0], [0, 0], [], []]
        self.game.animation = None
        self.game._rebuild_tubes()

        with patch.object(self.game.sound_effects, "play") as play:
            self.game._handle_tube_click(0)
            self.game._handle_tube_click(1)

        self.assertEqual(play.call_args_list, [call("select"), call("pour")])

    def test_solving_the_level_plays_a_completion_sound(self) -> None:
        self.game.board = [[0, 0], [0, 0], [], []]
        self.game.animation = None
        self.game._rebuild_tubes()
        self.game._handle_tube_click(0)
        self.game._handle_tube_click(1)
        assert self.game.animation is not None
        self.game.animation.elapsed = ANIMATION_DURATION

        with patch.object(self.game.sound_effects, "play") as play:
            self.game._update(_TaskStub())

        play.assert_called_once_with("success")
        self.assertIn(
            f'"level": {self.game.level}',
            self.game.progress_path.read_text(encoding="utf-8"),
        )
        self.assertFalse(self.game.celebration_text.isHidden())
        self.assertEqual(len(self.game.celebration_particles), 90)
        self.assertFalse(self.game.celebration_particles[0].node.isHidden())

    def test_celebration_effect_fades_and_cleans_up(self) -> None:
        self.game._start_celebration()
        self.assertEqual(len(self.game.celebration_particles), 90)

        self.game._update_celebration(3.1)

        self.assertIsNone(self.game.celebration_elapsed)
        self.assertTrue(self.game.celebration_text.isHidden())
        self.assertEqual(self.game.celebration_particles, [])

    def test_reduced_motion_keeps_success_message_without_confetti(self) -> None:
        self.game.reduced_motion = True
        self.addCleanup(setattr, self.game, "reduced_motion", False)
        self.game._start_celebration()

        self.assertFalse(self.game.celebration_text.isHidden())
        self.assertAlmostEqual(self.game.celebration_text.getScale()[0], 0.075)
        self.assertEqual(self.game.celebration_particles, [])

        self.game._update_celebration(0.5)
        self.assertAlmostEqual(self.game.celebration_text.getScale()[0], 0.075)
        self.game._update_celebration(3.1)
        self.assertTrue(self.game.celebration_text.isHidden())

    def test_completing_a_correctly_filled_tube_plays_confirmation_sound(self) -> None:
        self.game.board = [[1, 0, 0, 0], [0], [], []]
        self.game.animation = None
        self.game._rebuild_tubes()
        self.game._handle_tube_click(0)
        self.game._handle_tube_click(1)
        assert self.game.animation is not None
        self.game.animation.elapsed = ANIMATION_DURATION

        with patch.object(self.game.sound_effects, "play") as play:
            self.game._update(_TaskStub())

        play.assert_called_once_with("success")
        self.assertEqual(self.game.board[1], [0, 0, 0, 0])

    def test_hint_recommends_a_move_that_completes_a_tube(self) -> None:
        self.game.board = [[1, 0, 0, 0], [0], [], []]
        self.game._rebuild_tubes()

        with patch.object(self.game.sound_effects, "play") as play:
            self.game._show_hint()

        self.assertEqual(self.game.hinted_move, (0, 1))
        self.assertIn("Glas 1 in Glas 2", self.game.status_message)
        play.assert_called_once_with("select")

    def test_multiple_undo_actions_restore_the_previous_moves(self) -> None:
        self.game.board = [[0, 0], [1, 1], [], []]
        self.game.history.clear()
        self.game.move_count = 0
        self.game._rebuild_tubes()

        for source, target in ((0, 2), (1, 3)):
            self.game._handle_tube_click(source)
            self.game._handle_tube_click(target)
            assert self.game.animation is not None
            self.game.animation.elapsed = ANIMATION_DURATION
            self.game._update(_TaskStub())

        self.game._undo()
        self.game._undo()

        self.assertEqual(self.game.board, [[0, 0], [1, 1], [], []])
        self.assertEqual(self.game.move_count, 0)
        self.assertEqual(self.game.history, [])

    def test_action_buttons_have_room_for_their_labels(self) -> None:
        next_level_button = self.game.action_buttons[2]
        self.assertEqual(next_level_button["text"], "Nächstes Level")
        left, right, _, _ = next_level_button["frameSize"]
        self.assertGreaterEqual(right - left, 0.4)
        aspect = self.game.getAspectRatio()
        quit_button_right = (
            self.game.quit_button.getPos()[0]
            + self.game.quit_button["frameSize"][1]
        )
        self.assertLess(quit_button_right, aspect)

    def test_undo_button_is_green_and_hint_button_is_yellow(self) -> None:
        undo_color = self.game.action_buttons[0]["frameColor"][0]
        hint_color = self.game.action_buttons[3]["frameColor"][0]

        self.assertGreater(undo_color[1], undo_color[0])
        self.assertGreater(undo_color[1], undo_color[2])
        success_green = self.game.next_level_button_colors[0]
        self.assertGreater(success_green[1], undo_color[1])
        self.assertGreater(hint_color[0], hint_color[2])
        self.assertGreater(hint_color[1], hint_color[2])

    def test_next_level_button_blinks_and_respects_reduced_motion(self) -> None:
        button = self.game.action_buttons[2]
        default_colors = self.game.next_level_button_default_colors
        self.game.reduced_motion = False
        self.game.board = [[0, 0, 0, 0], [1, 1, 1, 1], [], []]
        self.game._rebuild_tubes()

        self.game.ui_time = 0.25
        self.game._sync_hud()
        bright_green = button["frameColor"][0][1]
        self.game.ui_time = 0.75
        self.game._update_next_level_button(True)
        dim_green = button["frameColor"][0][1]

        self.assertGreater(bright_green, dim_green)
        self.assertGreater(bright_green - dim_green, 0.1)

        self.game._toggle_reduced_motion()
        self.assertTrue(self.game.reduced_motion)
        self.assertEqual(self.game.motion_button["text"], "Effekte: ruhig")
        self.assertEqual(button["frameColor"][0], self.game.next_level_button_colors[0])
        self.game._toggle_reduced_motion()
        self.assertFalse(self.game.reduced_motion)
        self.assertEqual(self.game.motion_button["text"], "Effekte: an")

        self.game.board = [[0], [], [], []]
        self.game._rebuild_tubes()
        self.game._sync_hud()
        self.assertEqual(button["frameColor"], default_colors)

    def test_valid_target_pedestal_blinks_and_clears_after_selection(self) -> None:
        self.game.board = [[0, 0], [0], [], []]
        self.game.selected_tube = None
        self.game.hinted_move = None
        self.game.reduced_motion = False
        self.game._rebuild_tubes()
        self.game._handle_tube_click(0)

        self.game.ui_time = 0.25
        self.game._update_tube_accents()
        self.assertEqual(
            self.game.pedestals[1].getMaterial(),
            self.game.target_base_material,
        )
        self.assertEqual(
            self.game.pedestals[2].getMaterial(),
            self.game.target_base_material,
        )

        self.game.ui_time = 0.75
        self.game._update_tube_accents()
        self.assertEqual(self.game.pedestals[1].getMaterial(), self.game.base_material)
        self.assertEqual(self.game.pedestals[2].getMaterial(), self.game.base_material)

        self.game._clear_selection()
        self.assertEqual(self.game.pedestals[1].getMaterial(), self.game.base_material)

    def test_difficulty_modes_adjust_colors_empty_tubes_and_progression(self) -> None:
        previous_level = self.game.level
        previous_difficulty = self.game.difficulty

        def restore_level() -> None:
            self.game.level = previous_level
            self.game.difficulty = previous_difficulty
            self.game._start_level()

        self.addCleanup(restore_level)
        configurations = (
            ("leicht", 2, 3),
            ("mittel", 3, 2),
            ("schwer", 9, 1),
        )
        for difficulty, expected_colors, expected_extra_tubes in configurations:
            with self.subTest(difficulty=difficulty):
                self.game.level = 1
                self.game.difficulty = difficulty
                self.game._start_level()
                colors = {
                    color
                    for tube in self.game.board
                    for color in tube
                }
                self.assertEqual(len(colors), expected_colors)
                self.assertEqual(
                    len(self.game.board),
                    expected_colors + expected_extra_tubes,
                )

        for difficulty, level, expected_colors in (
            ("leicht", 4, 3),
            ("mittel", 3, 4),
            ("schwer", 2, 9),
        ):
            with self.subTest(difficulty=difficulty, level=level):
                self.game.difficulty = difficulty
                self.game.level = level
                self.game._start_level()
                colors = {
                    color
                    for tube in self.game.board
                    for color in tube
                }
                self.assertEqual(len(colors), expected_colors)

        hard_settings = DIFFICULTY_SETTINGS["schwer"]
        self.assertEqual(hard_settings.starting_colors, 9)
        self.assertEqual(hard_settings.capacity, 6)
        self.assertEqual(hard_settings.max_scramble_pour, 3)
        self.assertEqual(hard_settings.max_colors, 9)
        self.assertEqual(DIFFICULTY_SETTINGS["mittel"].max_colors, 7)
        self.assertGreaterEqual(
            hard_settings.scramble_base
            + 9 * hard_settings.scramble_per_color,
            1300,
        )

    def test_hard_mode_starts_with_six_layers_per_color_and_fits_the_glass(self) -> None:
        self.game.difficulty = "schwer"
        self.game.level = 1
        self.game._start_level()

        self.assertEqual(self.game.capacity, 6)
        self.assertEqual(len(self.game.board), 10)
        self.assertEqual(sum(map(len, self.game.board)), 54)
        self.assertTrue(
            all(len(tube) <= self.game.capacity for tube in self.game.board)
        )
        self.assertEqual(
            len({color for tube in self.game.board for color in tube}),
            9,
        )
        self.assertAlmostEqual(
            self.game.liquid_slot_height * self.game.capacity,
            CAPACITY * 0.57,
        )

        self.game.board = [[0] * 6, *([] for _ in range(9))]
        self.game.animation = None
        self.game._rebuild_tubes()
        self.assertFalse(self.game.liquid_surfaces[0].isHidden())
        self.assertLess(self.game._liquid_surface_point(0).z, 2.8)
        self.assertAlmostEqual(self.game.liquid_parts[0][0].getSz(), 4.0)
        self.assertTrue(is_solved(self.game.board, self.game.capacity))

    def test_selecting_difficulty_restarts_and_persists_the_current_level(self) -> None:
        previous_level = self.game.level
        previous_difficulty = self.game.difficulty

        def restore_level() -> None:
            self.game.level = previous_level
            self.game.difficulty = previous_difficulty
            self.game._start_level()

        self.addCleanup(restore_level)
        self.game.level = 2
        self.game.difficulty = "mittel"
        self.game._start_level()

        self.game._select_difficulty("schwer")

        self.assertEqual(self.game.level, 2)
        self.assertEqual(self.game.difficulty, "schwer")
        self.assertEqual(load_progress(self.game.progress_path), (2, "schwer"))
        self.assertEqual(
            [button["text"] for button in self.game.difficulty_buttons],
            ["LEICHT", "MITTEL", "SCHWER"],
        )
        self.assertEqual(
            self.game.difficulty_buttons[2]["frameColor"],
            self.game.difficulty_button_selected_colors,
        )

    def test_only_tube_numbers_are_shown_below_the_glasses(self) -> None:
        self.game.board = [[0, 2, 3], [6], [], []]
        self.game._rebuild_tubes()
        self.game._sync_hud()

        self.assertEqual(len(self.game.tube_numbers), len(self.game.board))
        self.assertEqual(
            [label.getText() for label in self.game.tube_numbers],
            [str(index + 1) for index in range(len(self.game.board))],
        )
        self.assertFalse(hasattr(self.game, "tube_color_labels"))

    def test_hint_and_selection_use_distinct_consistent_state_colors(self) -> None:
        self.game.board = [[0, 0], [], [], []]
        self.game._rebuild_tubes()
        self.game._handle_tube_click(0)
        selection_color = self.game.tube_accents[0].getColorScale()
        target_color = self.game.tube_accents[1].getColorScale()

        self.assertGreater(selection_color[1], selection_color[0])
        self.assertGreater(target_color[1], target_color[0])

        self.game._show_hint()
        hint_color = self.game.tube_accents[0].getColorScale()
        self.assertGreater(hint_color[0], hint_color[1])

    def test_level_buttons_navigate_and_persist_the_selected_level(self) -> None:
        self.game.level = 1
        self.game.difficulty = "mittel"
        self.game.animation = None
        self.game._previous_level()
        self.assertEqual(self.game.level, 1)

        self.game._next_level()
        self.assertEqual(self.game.level, 2)
        self.assertEqual(
            self.game.progress_path.read_text(encoding="utf-8"),
            '{"level": 2, "difficulty": "mittel"}',
        )

        self.game._previous_level()
        self.assertEqual(self.game.level, 1)
        self.assertEqual(
            self.game.progress_path.read_text(encoding="utf-8"),
            '{"level": 1, "difficulty": "mittel"}',
        )
        self.assertEqual([button["text"] for button in self.game.level_buttons], ["<", ">"])

    def test_pour_animation_commits_complete_matching_color_stack(self) -> None:
        self.game.board = [[0, 2, 2, 2], [2, 2], [], []]
        self.game._rebuild_tubes()
        self.game._handle_tube_click(0)
        self.game._handle_tube_click(1)

        self.assertIsNotNone(self.game.animation)
        assert self.game.animation is not None
        self.assertEqual(self.game.animation.amount, 2)

        self.game.animation.elapsed = ANIMATION_DURATION
        self.game._update(_TaskStub())

        self.assertEqual(self.game.board, [[0, 2], [2, 2, 2, 2], [], []])
        self.assertIsNone(self.game.animation)

    def test_pour_animation_advances_twice_as_fast(self) -> None:
        self.game.board = [[0, 0], [0], [], []]
        self.game._rebuild_tubes()
        self.game._handle_tube_click(0)
        self.game._handle_tube_click(1)
        animation = self.game.animation
        self.assertIsNotNone(animation)
        assert animation is not None

        with (
            patch("panda3d_game.ClockObject") as clock_object,
            patch.object(self.game, "_pour_pose", return_value=(0.0, 0.0, 0.0)),
            patch.object(self.game, "_update_liquid"),
            patch.object(self.game, "_update_liquid_surface_motion"),
            patch.object(self.game, "_update_stream"),
        ):
            clock_object.getGlobalClock.return_value.getDt.return_value = 0.05
            self.game._update(_TaskStub())

        self.assertAlmostEqual(animation.elapsed, 0.1)

    def test_interpolated_liquid_segments_conserve_volume(self) -> None:
        self.game.board = [[0, 2, 2], [2], [], []]
        self.game._rebuild_tubes()
        self.game._handle_tube_click(0)
        self.game._handle_tube_click(1)
        animation = self.game.animation
        self.assertIsNotNone(animation)
        assert animation is not None
        animation.elapsed = 0.62

        volume = sum(
            amount
            for tube_index in (animation.source, animation.target)
            for _, amount in self.game._liquid_segments(tube_index)
        )
        self.assertAlmostEqual(volume, 4)

    def test_pour_stream_uses_the_transferred_liquid_color(self) -> None:
        self.game.board = [[0, 2], [], [], []]
        self.game._rebuild_tubes()
        self.game._handle_tube_click(0)
        self.game._handle_tube_click(1)
        animation = self.game.animation
        self.assertIsNotNone(animation)
        assert animation is not None
        animation.elapsed = 0.56

        self.game._update(_TaskStub())

        expected = tuple(channel / 255 for channel in PALETTE[2][1])
        actual = self.game.stream_segments[0].getColorScale()
        for index, expected_channel in enumerate(expected):
            self.assertAlmostEqual(actual[index], expected_channel, places=3)
        self.assertEqual(len(self.game.stream_segments), 32)
        self.assertIsNotNone(self.game.stream_ripple)
        self.assertGreater(
            self.game.stream_segments[0].getScale()[0],
            self.game.stream_segments[-1].getScale()[0],
        )

    def test_pour_stream_starts_at_the_lower_edge_of_the_source_rim(self) -> None:
        self.game.board = [[0, 2], [], [], []]
        self.game.animation = None
        self.game._rebuild_tubes()
        self.game._handle_tube_click(0)
        self.game._handle_tube_click(1)
        assert self.game.animation is not None
        self.game.animation.elapsed = 0.58

        self.game._update(_TaskStub())

        assert self.game.stream_segments
        source = self.game.vessel_roots[self.game.animation.source]
        expected_start = source.getMat(self.game.render).xformPoint(
            Point3(0.38, 0, 2.78)
        )
        actual_start = self.game.stream_segments[0].getPos(self.game.render)
        self.assertLess((actual_start - expected_start).length(), 0.001)
        center_start = source.getMat(self.game.render).xformPoint(Point3(0, 0, 2.86))
        self.assertGreater((actual_start - center_start).length(), 0.2)
        self.game.animation = None
        self.game._set_stream(False)

    def test_liquid_flow_begins_after_the_tube_has_tilted(self) -> None:
        self.game.board = [[0, 2], [], [], []]
        self.game.animation = None
        self.game._rebuild_tubes()
        self.game._handle_tube_click(0)
        self.game._handle_tube_click(1)
        assert self.game.animation is not None

        self.game.animation.elapsed = POUR_START - 0.01
        before_flow = self.game._liquid_segments(0)
        self.game.animation.elapsed = POUR_START + 0.01
        during_flow = self.game._liquid_segments(0)

        self.assertEqual(before_flow, [(0, 1.0), (2, 1.0)])
        self.assertLess(sum(amount for _, amount in during_flow), 2)
        self.game.animation = None
        self.game._set_stream(False)

    def test_pour_stream_tracks_the_rising_target_surface(self) -> None:
        self.game.board = [[2], [2], [], []]
        self.game._rebuild_tubes()
        self.game._handle_tube_click(0)
        self.game._handle_tube_click(1)
        animation = self.game.animation
        self.assertIsNotNone(animation)
        assert animation is not None

        animation.elapsed = 0.50
        self.game._update(_TaskStub())
        initial_surface = self.game._liquid_surface_point(animation.target).z
        self.assertIsNotNone(self.game.stream_ripple)
        assert self.game.stream_ripple is not None
        initial_ripple = self.game.stream_ripple.getZ()

        animation.elapsed = 1.20
        self.game._update(_TaskStub())
        filled_surface = self.game._liquid_surface_point(animation.target).z

        self.assertGreater(filled_surface - initial_surface, 0.3)
        self.assertGreater(self.game.stream_ripple.getZ() - initial_ripple, 0.3)

    def test_pour_stream_ends_before_the_source_tube_returns(self) -> None:
        self.game.board = [[1, 0, 0], [0], [], []]
        self.game._rebuild_tubes()
        self.game._handle_tube_click(0)
        self.game._handle_tube_click(1)
        animation = self.game.animation
        self.assertIsNotNone(animation)
        assert animation is not None

        animation.elapsed = POUR_END
        source_segments = self.game._liquid_segments(animation.source)
        target_segments = self.game._liquid_segments(animation.target)
        self.assertEqual(source_segments, [(1, 1.0)])
        self.assertEqual(target_segments, [(0, 3.0)])
        self.assertAlmostEqual(abs(self.game._pour_pose()[0]), 66)

        animation.elapsed = STREAM_END
        self.game._update_stream()
        self.assertEqual(self.game.stream_segments, [])
        self.assertIsNone(self.game.stream_ripple)
        self.assertAlmostEqual(abs(self.game._pour_pose()[0]), 66)

        animation.elapsed = RETURN_START + 0.18
        self.assertLess(abs(self.game._pour_pose()[0]), 66)
        self.game.animation = None
        self.game.selected_tube = None
        self.game._set_stream(False)

    def test_tube_accents_distinguish_selection_and_valid_targets(self) -> None:
        self.game.board = [[0, 0], [1], [], []]
        self.game._rebuild_tubes()
        self.game._handle_tube_click(0)

        selected = self.game.tube_accents[0].getColorScale()
        invalid_target = self.game.tube_accents[1].getColorScale()
        valid_target = self.game.tube_accents[2].getColorScale()
        self.assertGreater(selected[1], selected[0])
        self.assertLess(invalid_target[3], 0.3)
        self.assertGreater(valid_target[3], 0.7)


if __name__ == "__main__":
    unittest.main()
