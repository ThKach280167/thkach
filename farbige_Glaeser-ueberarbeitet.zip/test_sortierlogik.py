import unittest
from collections import Counter

from sortierlogik import can_pour, create_puzzle, is_solved, pour


class PourTests(unittest.TestCase):
    def test_pours_the_top_color_group(self) -> None:
        board = [[0, 1, 1], []]

        amount = pour(board, 0, 1)

        self.assertEqual(amount, 2)
        self.assertEqual(board, [[0], [1, 1]])

    def test_pour_stops_at_target_capacity(self) -> None:
        board = [[1, 1, 1], [0, 1, 1]]

        amount = pour(board, 0, 1)

        self.assertEqual(amount, 1)
        self.assertEqual(board, [[1, 1], [0, 1, 1, 1]])

    def test_rejects_a_different_color_without_changing_the_board(self) -> None:
        board = [[0, 1], [2]]
        before = [tube.copy() for tube in board]

        self.assertFalse(can_pour(board, 0, 1))
        with self.assertRaises(ValueError):
            pour(board, 0, 1)
        self.assertEqual(board, before)


class PuzzleTests(unittest.TestCase):
    def test_puzzle_has_the_requested_color_counts_and_is_unsolved(self) -> None:
        board = create_puzzle(color_count=3, scramble_steps=90, seed=7)

        self.assertEqual(len(board), 5)
        self.assertEqual(Counter(color for tube in board for color in tube), {
            0: 4,
            1: 4,
            2: 4,
        })
        self.assertFalse(is_solved(board))

    def test_seed_makes_puzzle_generation_repeatable(self) -> None:
        first = create_puzzle(color_count=3, scramble_steps=50, seed=12)
        second = create_puzzle(color_count=3, scramble_steps=50, seed=12)

        self.assertEqual(first, second)

    def test_scramble_pour_limit_preserves_a_valid_unsolved_puzzle(self) -> None:
        board = create_puzzle(
            color_count=7,
            empty_tubes=1,
            scramble_steps=735,
            max_scramble_pour=1,
            seed=0,
        )

        layer_runs = sum(
            1 + sum(left != right for left, right in zip(tube, tube[1:]))
            for tube in board
            if tube
        )
        self.assertGreaterEqual(layer_runs, 16)
        self.assertEqual(
            Counter(color for tube in board for color in tube),
            Counter({color: 4 for color in range(7)}),
        )
        self.assertEqual(len(board), 8)
        self.assertFalse(is_solved(board))

    def test_hard_mode_puzzle_has_nine_colors_and_many_mixed_layers(self) -> None:
        board = create_puzzle(
            color_count=9,
            empty_tubes=1,
            capacity=6,
            scramble_steps=1320,
            max_scramble_pour=3,
            seed=0,
        )

        layer_runs = sum(
            1 + sum(left != right for left, right in zip(tube, tube[1:]))
            for tube in board
            if tube
        )
        self.assertEqual(len(board), 10)
        self.assertEqual(
            Counter(color for tube in board for color in tube),
            Counter({color: 6 for color in range(9)}),
        )
        self.assertGreaterEqual(layer_runs, 25)
        self.assertFalse(is_solved(board, capacity=6))

    def test_rejects_non_positive_scramble_pour_limit(self) -> None:
        with self.assertRaises(ValueError):
            create_puzzle(color_count=2, max_scramble_pour=0)

    def test_scrambled_puzzles_are_never_already_solved(self) -> None:
        for seed in range(20):
            board = create_puzzle(
                color_count=1,
                empty_tubes=1,
                capacity=2,
                scramble_steps=1,
                seed=seed,
            )
            with self.subTest(seed=seed):
                self.assertFalse(is_solved(board, capacity=2))

    def test_a_solved_board_requires_full_single_color_tubes(self) -> None:
        self.assertTrue(is_solved([[0, 0, 0, 0], [], [1, 1, 1, 1]]))
        self.assertFalse(is_solved([[0, 0, 0], [1, 1, 1, 1]]))
        self.assertFalse(is_solved([[0, 1, 0, 1], []]))


if __name__ == "__main__":
    unittest.main()
